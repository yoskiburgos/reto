# Gobierno de Pipelines: Reglas por Tier y Plan de Adopción (`supply-chain/tiers.md`)

## 1. Matriz de Política como Código por Tier (`policies.yml`)

El motor [`supply-chain/policy-check.py`](./policy-check.py) evalúa cada workflow contra el catálogo declarativo [`supply-chain/policies.yml`](./policies.yml). Toda regla tiene severidad `BLOCKING` (falla el pipeline con `exit 1`) o `WARNING` (avisa en el resumen sin romper el flujo) según la criticidad del negocio:

| Categoría / Regla (`id`) | Qué audita técnicamente | Tier 0 (`checkout`, `payments`, `ledger`, `fraud`) | Tier 1 (`catalog`, `search`, `identity`, `mobile-*`) | Tier 2 (`reporting`, `notifications`, `data-platform`) | Tier 3 (Herramientas internas) |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **`SEC-001` Permisos Mínimos** | `permissions:` raíz restringido a `contents: read` (prohibido `write-all`). Elevación solo por job (`id-token: write`, `packages: write`). | **BLOCKING** | **BLOCKING** | **BLOCKING** | **BLOCKING** |
| **`SEC-002` Sin `pull_request_target`** | Prohibido el trigger `pull_request_target` (previene ataques *Pwn Request* con checkout de código no confiable). | **BLOCKING** | **BLOCKING** | **BLOCKING** | **BLOCKING** |
| **`SEC-003` Pinning por SHA (40 hex)** | Toda acción (`uses:`) debe fijarse a un commit SHA inmutable de 40 caracteres hex (prohibido `@main`, `@latest`, `@v3`, `@v4`). | **BLOCKING** | **BLOCKING** | **BLOCKING** | **BLOCKING** |
| **`SEC-004` Checkout Seguro** | `actions/checkout` debe incluir `with: { persist-credentials: false }`. | **BLOCKING** | **BLOCKING** | **BLOCKING** | **BLOCKING** |
| **`SEC-005` Sin Secretos en Claro** | Prohibido definir contraseñas, tokens o API keys literales en `env:` o `run:`. Deben inyectarse desde `secrets.*` solo en el step que los usa. | **BLOCKING** | **BLOCKING** | **BLOCKING** | **BLOCKING** |
| **`SEC-006` Sin Inyección de Contexto** | Prohibido interpolar `${{ github.event.pull_request.title }}`, `${{ github.head_ref }}`, etc. directamente dentro de `run:`. | **BLOCKING** | **BLOCKING** | **BLOCKING** | **BLOCKING** |
| **`SEC-007` Tag de Imagen Inmutable** | Prohibido construir o publicar imágenes con tag `:latest` (`docker build -t app:latest`). Exige SHA o versión semántica. | **BLOCKING** | **BLOCKING** | **BLOCKING** | **WARNING** |
| **`REL-001` Timeout Obligatorio** | Todos los jobs deben declarar `timeout-minutes` ($\le 60\text{ min}$). | **BLOCKING** | **BLOCKING** | **BLOCKING** | **BLOCKING** |
| **`REL-002` Control de Concurrencia** | Definición de `concurrency:` para cancelar runs obsoletos en PR sin cancelar despliegues productivos. | **WARNING** | **WARNING** | **WARNING** | **INFO** |
| **`GATE-001` Gates No Ignorables** | Prohibido silenciar escáneres con `\|\| true`, `continue-on-error: true` o invocarlos sin su variable de autenticación desde `secrets.*`. | **BLOCKING** | **BLOCKING** | **BLOCKING** | **BLOCKING** |
| **`GATE-002` Umbrales por Tier** | Reglas explícitas obligatorias (`--fail-on`, `--gate`, `--sla`):<br>• **Tier 0:** SAST/SCA/DAST `critical=0,high=0`; Sonar `coverage>=80,bugs<=0,vulnerabilities<=0`.<br>• **Tier 1:** SAST/SCA `critical=0,high=0`, licencias denegadas `GPL-3.0,AGPL-3.0`; Sonar `coverage>=80,bugs<=0,vulnerabilities<=0`.<br>• **Tier 2:** SAST/SCA `critical=0,high<=5`; Sonar `coverage>=70,bugs<=0,vulnerabilities<=0`.<br>• **Tier 3:** SAST/SCA `critical=0,high<=10`. | **BLOCKING** | **BLOCKING** | **BLOCKING** | **BLOCKING** |
| **`GATE-TIER-REQ` Cobertura de Gates** | Presencia obligatoria de etapas de escaneo según criticidad:<br>• **Tier 0:** SAST + Calidad/Seguridad bloqueantes + Procedencia/Aprobación en CD.<br>• **Tier 1:** SAST + SCA + Calidad bloqueantes.<br>• **Tier 2:** SAST + SCA bloqueantes.<br>• **Tier 3:** Mínimos comunes de seguridad (`SEC-001..006`, `REL-001`). | **BLOCKING** | **BLOCKING** | **BLOCKING** | **INFO** |
| **`CD-001` Gobierno de Despliegue** | Todo job que ejecute `kubectl apply` / `helm upgrade` requiere etapa previa de pruebas (`needs:` / `mvn verify`) y `environment:` con aprobación. | **BLOCKING** | **BLOCKING** | **WARNING** | **INFO** |

### Gestión de Excepciones con Caducidad (`exceptions.yml`)
- Ningún squad puede desactivar una regla editando su pipeline con `|| true`. Toda excepción temporal se registra mediante Pull Request en [`supply-chain/exceptions.yml`](./exceptions.yml) (protegido por `CODEOWNERS` de Seguridad y Plataforma) con tres campos obligatorios: `owner` (responsable nominal), `reason` (justificación de negocio/mitigación) y `expires` (fecha ISO `YYYY-MM-DD`, máximo 14 días en Tier 0, 30 días en Tier 1 y 45 días en Tier 2).
- **Comportamiento Fail-Closed:** Si `expires < fecha_actual`, `policy-check.py` marca la excepción como **`EXPIRED`**, imprime una alerta explícita de auditoría y **vuelve a bloquear el pipeline (`exit 1`)** sin intervención humana.

---

## 2. Plan de Adopción y Migración de 1 Página (Sin Cuello de Botella en los 6 FTE)

### 2.1 Principio Rector: "Golden Paths Self-Service + Enforcement Gradual (Audit $\rightarrow$ Warn $\rightarrow$ Block)"
Si los 6 FTE de plataforma intentan escribir o revisar manualmente los pipelines de los 12 squads (~85 ingenieros), se convertirán en un cuello de botella inmediato. La estrategia desacopla la **autoría de políticas y plantillas** (Plataforma) de la **adopción y corrección del código** (Squads):

1. **Catálogo de Workflows Reutilizables (`workflow_call`):** Plataforma publica y mantiene 2 workflows reutilizables parametrizados por `tier` (`.github/workflows/reusable-java-ci.yml`). Un squad adopta el estándar completo invocando `uses: ./.github/workflows/reusable-java-ci.yml` con `with: { tier: tier1, project-key: catalog }` en menos de 20 líneas de YAML.
2. **Despliegue de `policy-check.py` mediante GitHub Organization Rulesets en 3 Fases:**
   - **Semana 1–2 (Modo Sombra / Telemetría):** `policy-check.py` corre en todos los PRs publicando hallazgos en `$GITHUB_STEP_SUMMARY` sin bloquear, salvo para secretos en claro (`SEC-005`) y `pull_request_target` (`SEC-002`), que bloquean desde el Día 1.
   - **Semana 3–6 (Bloqueo en Reglas Comunes y SAST/SCA para Auditoría Q1):** Bloqueo activo (`exit 1`) en Tier 0, Tier 1 y Tier 2 para `SEC-001..007`, `REL-001`, `GATE-001` y presencia de SAST/SCA. Los squads con deuda legacy de cobertura unitaria o hallazgos heredados registran una excepción acotada a 30 días en `exceptions.yml` vinculada a un épico de Jira (`DEVOPS-XXX`).
   - **Semana 7–12 (Enforcement Total Pre-Auditoría):** Bloqueo completo por tier (`GATE-002`, `GATE-TIER-REQ`, `CD-001`) y caducidad automática de las excepciones iniciales.

### 2.2 Estrategia de Migración de los 5 Squads en Jenkins (`ledger`, `reporting`, `search`, `identity`, `fraud`) y los 2 sin Pipeline (`data-platform`, `mobile-ios`)

El controlador único de Jenkins (1 controller, 6 agentes) es un **Punto Único de Fallo (SPOF)** y concentra 14 incidentes (102.0 h de caída). Lo migraremos y apagaremos en **3 oleadas (Waves)** sin congelar entregas de negocio:

| Oleada | Squads | Estado Actual | Estrategia Técnica de Migración (Patrón *Strangler Fig*) | Criterio de Apagado en Jenkins |
| :---: | :--- | :--- | :--- | :--- |
| **Wave 1 (M1–M2)** *Emergencia Sev1 y Sin Pipeline* | `data-platform` (none)<br>`mobile-ios` (none)<br>`ledger` (Jenkins/GHA roto) | Concentran 5 de 6 Sev1, 0 escaneo de seguridad y despliegues manuales. | • Envolver sus scripts de empaquetado actuales dentro del workflow reutilizable de GHA con SAST+SCA obligatorio y tests de humo.<br>• Revocar credenciales directas de base de datos/AKS (`Led9er-Pr0d-2023`) y migrar a OIDC + secretos de entorno.<br>• Embebido temporal de 2 ingenieros de plataforma (3 semanas) para pair-programming con el squad (*Enabling Team*). | `ledger` ejecuta 4 releases consecutivos desde GHA con `policy-check.py` en `PASS`; su job en Jenkins pasa a *Read-Only / Disabled*. |
| **Wave 2 (M3–M5)** *Cierre de Brecha SAST/SCA* | `reporting` (Jenkins)<br>`search` (Jenkins) | `reporting` (1 Sev1, CFR 27%) y `search` (escaneo parcial, sin gates reales). | • Traducir declarativamente sus `Jenkinsfile` (Groovy) a llamadas al workflow reutilizable de GHA usando el generador/plantilla de plataforma.<br>• Ejecución en paralelo en PR durante 2 sprints (Jenkins + GHA); el despliegue pasa a ser exclusivo desde GHA. | Tras 2 semanas en verde en GHA, se archivan los jobs en Jenkins y se liberan 3 de los 6 agentes de Jenkins. |
| **Wave 3 (M6–M8)** *Decomiso Total de Jenkins* | `identity` (Jenkins)<br>`fraud` (Jenkins) | Squads con madurez media/alta (`semi`, SAST/SCA `yes`) pero atados a pipelines legacy en Jenkins. | • Migración autoservicio guiada por los *DevSecOps Champions* de cada squad usando la plantilla ya probada en Waves 1 y 2.<br>• Promoción de modo `semi` a `auto` con `environment: production` y validaciones post-deploy automáticas. | **Fin de M8:** 0 builds en Jenkins durante 14 días $\rightarrow$ snapshot final de auditoría en almacenamiento frío y **apagado definitivo del controlador Jenkins**. |
