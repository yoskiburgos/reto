#!/usr/bin/env python3
"""
Tarea 5 — Gobierno de Pipelines: Auditor de Política como Código (supply-chain/policy-check.py)

Audita archivos de workflow de GitHub Actions (.yml/.yaml) contra el catálogo declarativo
de reglas por Tier (`supply-chain/policies.yml`) y procesa excepciones con caducidad
(`supply-chain/exceptions.yml` con campos obligatorios: owner, reason, expires).

Características:
- Reglas definidas 100% como datos en `policies.yml` (sin `if`s dispersos por squad).
- Detección precisa sin falsos positivos en el workflow sano (`checkout.yml`) ni en workflows reutilizables (`workflow_call`).
- Soporte de excepciones temporales con verificación de fecha de caducidad (`--as-of YYYY-MM-DD`).
- Código de salida != 0 (exit 1) cuando existen violaciones BLOCKING no cubiertas por una excepción vigente.
"""
import argparse
from datetime import date
import json
from pathlib import Path
import re
import sys
import yaml

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DEFAULT_WORKFLOWS = ROOT / "ejercicios" / "master" / "org-workflows"
DEFAULT_POLICIES = HERE / "policies.yml"
DEFAULT_EXCEPTIONS = HERE / "exceptions.yml"


def extract_metadata_from_header(raw_text: str, file_path: Path, squad_tiers: dict) -> tuple[str, str]:
    """Extrae squad y tier del comentario de cabecera (# squad: X (tierY)) o del mapa declarativo."""
    m = re.search(r"#\s*squad:\s*([a-zA-Z0-9_-]+)\s*\((tier[0-3])\)", raw_text)
    if m:
        return m.group(1).lower(), m.group(2).lower()
    stem = file_path.stem.lower()
    squad = stem
    tier = squad_tiers.get(squad, "tier1")
    return squad, tier


def normalize_on_triggers(doc: dict) -> dict:
    raw_on = doc.get("on") if "on" in doc else doc.get(True, {})
    if isinstance(raw_on, str):
        return {raw_on: {}}
    if isinstance(raw_on, list):
        return {str(k): {} for k in raw_on}
    if isinstance(raw_on, dict):
        return {str(k): (v or {}) for k, v in raw_on.items()}
    return {}


def normalize_shell_continuations(text: str) -> str:
    """Une líneas continuadas con '\\' en bloques shell para analizar flags de comandos multi-línea."""
    return re.sub(r"\\\s*\n\s*", " ", str(text or ""))


def iter_jobs_and_steps(doc: dict):
    jobs = doc.get("jobs") or {}
    for job_id, job in jobs.items():
        if not isinstance(job, dict):
            continue
        steps = job.get("steps") or []
        yield job_id, job, steps


# ---------------------------------------------------------------------------
# Detectores genéricos orientados a datos (Data-Driven Rule Evaluators)
# ---------------------------------------------------------------------------

def detect_workflow_permissions(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    perms = doc.get("permissions")
    if perms is None:
        issues.append("El workflow no declara `permissions:` explícitos a nivel raíz (principio de privilegio mínimo).")
        return issues
    if isinstance(perms, str):
        if perms in params.get("forbidden_values", []) or perms not in params.get("allowed_top_level_values", []):
            issues.append(f"Permisos globales excesivos a nivel de workflow (`permissions: {perms}`). Use `contents: read`.")
    elif isinstance(perms, dict):
        allowed_scopes = params.get("allowed_top_level_Scopes", {})
        for scope, val in perms.items():
            allowed_vals = allowed_scopes.get(scope, ["read", "none"])
            if val not in allowed_vals:
                issues.append(f"Permiso elevado a nivel global (`{scope}: {val}`); elévelo solo en el job que lo requiera.")
    return issues


def detect_forbidden_triggers(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    triggers = normalize_on_triggers(doc)
    for forbidden in params.get("forbidden_events", []):
        if forbidden in triggers:
            issues.append(f"Disparador inseguro `{forbidden}` detectado (riesgo de ejecución de código no confiable con acceso a secretos).")
    return issues


def detect_action_pinning(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    sha_re = re.compile(params.get("sha_regex", "^[0-9a-f]{40}$"))
    for job_id, _, steps in iter_jobs_and_steps(doc):
        for idx, step in enumerate(steps, 1):
            uses = step.get("uses")
            if not uses or uses.startswith("./"):
                continue
            if "@" not in uses:
                issues.append(f"Job `{job_id}` step #{idx}: acción `{uses}` sin versión ni SHA fijado.")
                continue
            _, ref = uses.rsplit("@", 1)
            if not sha_re.match(ref):
                issues.append(
                    f"Job `{job_id}` step #{idx}: acción `{uses}` usa referencia mutable (`@{ref}`) en lugar de SHA de 40 caracteres hex."
                )
    return issues


def detect_checkout_persist_credentials(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    for job_id, _, steps in iter_jobs_and_steps(doc):
        for idx, step in enumerate(steps, 1):
            uses = step.get("uses", "")
            if uses.startswith("actions/checkout@"):
                with_block = step.get("with") or {}
                if with_block.get("persist-credentials") is not False:
                    issues.append(
                        f"Job `{job_id}` step #{idx} (`{uses}`): falta `with: {{ persist-credentials: false }}`."
                    )
    return issues


def detect_no_hardcoded_secrets(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    key_re = re.compile(params.get("sensitive_key_regex", "(?i)(password|secret|token|api_key)"))
    allowed_prefixes = tuple(params.get("allowed_value_prefixes", ["${{ secrets."]))

    def check_env_map(env_map: dict, location: str):
        if not isinstance(env_map, dict):
            return
        for k, v in env_map.items():
            if key_re.search(str(k)):
                sval = str(v).strip()
                if not sval.startswith(allowed_prefixes):
                    issues.append(
                        f"{location}: posible secreto en texto claro en `{k}` (debe inyectarse desde `secrets.*`)."
                    )

    check_env_map(doc.get("env") or {}, "Workflow `env`")
    for job_id, job, steps in iter_jobs_and_steps(doc):
        check_env_map(job.get("env") or {}, f"Job `{job_id}.env`")
        for idx, step in enumerate(steps, 1):
            check_env_map(step.get("env") or {}, f"Job `{job_id}` step #{idx} `env`")
    return issues


def detect_no_context_injection(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    untrusted = params.get("untrusted_contexts", [])
    for job_id, _, steps in iter_jobs_and_steps(doc):
        for idx, step in enumerate(steps, 1):
            run_cmd = step.get("run")
            if not run_cmd:
                continue
            for ctx in untrusted:
                pattern = re.compile(r"\$\{\{\s*" + re.escape(ctx) + r"\b[^}]*\}\}")
                if pattern.search(str(run_cmd)):
                    issues.append(
                        f"Job `{job_id}` step #{idx}: inyección de contexto no confiable `${{{{ {ctx} }}}}` interpolado directamente en `run:` (páselo por `env:`)."
                    )
    return issues


def detect_no_mutable_docker_tag(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    regex = re.compile(params.get("forbidden_docker_build_regex", r"docker\s+(build|push|tag)\s+[^\n]*:latest\b"))
    for job_id, _, steps in iter_jobs_and_steps(doc):
        for idx, step in enumerate(steps, 1):
            run_cmd = normalize_shell_continuations(step.get("run") or "")
            if regex.search(run_cmd):
                issues.append(f"Job `{job_id}` step #{idx}: uso de tag de contenedor mutable `:latest` en `run:`.")
    return issues


def detect_job_timeout(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    max_t = params.get("max_timeout_minutes", 60)
    for job_id, job, _ in iter_jobs_and_steps(doc):
        # En GitHub Actions, un job que invoca un reusable workflow (`uses: ./.github/workflows/...`)
        # delega el `timeout-minutes` a los jobs internos del workflow llamado.
        if job.get("uses") and not job.get("steps"):
            continue
        t = job.get("timeout-minutes")
        if t is None:
            issues.append(f"Job `{job_id}` no define `timeout-minutes`.")
        elif not isinstance(t, (int, float)) or t <= 0 or t > max_t:
            issues.append(f"Job `{job_id}` tiene `timeout-minutes: {t}` fuera del rango permitido (1..{max_t}).")
    return issues


def detect_workflow_concurrency(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    triggers = normalize_on_triggers(doc)
    # Un workflow puramente reutilizable (solo `workflow_call`) hereda la concurrencia del workflow invocador
    if list(triggers.keys()) == ["workflow_call"]:
        return []
    if doc.get("concurrency"):
        return []
    for _, job, _ in iter_jobs_and_steps(doc):
        if job.get("concurrency"):
            return []
    return ["El workflow no define `concurrency:` para cancelar ejecuciones obsoletas y proteger despliegues."]


def detect_no_ignorable_gates(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    gate_bins = params.get("gate_binaries", {})
    bypass_re = re.compile(params.get("bypass_regex", r"(\|\|\s*true\b|\|\|\s*:|set\s+\+e)"))
    for job_id, job, steps in iter_jobs_and_steps(doc):
        for idx, step in enumerate(steps, 1):
            run_cmd = normalize_shell_continuations(step.get("run") or "")
            matched_bins = [b for b in gate_bins if b in run_cmd]
            if not matched_bins:
                continue
            step_name = step.get("name") or f"step #{idx}"
            if step.get("continue-on-error") is True:
                issues.append(f"Job `{job_id}` ({step_name}): gate con `continue-on-error: true` (no bloqueante).")
            if bypass_re.search(run_cmd):
                issues.append(f"Job `{job_id}` ({step_name}): gate silenciado con `{bypass_re.search(run_cmd).group(0)}` en `run:`.")
            for b in matched_bins:
                req_env = gate_bins[b]
                if req_env:
                    step_env = step.get("env") or {}
                    job_env = job.get("env") or {}
                    wf_env = doc.get("env") or {}
                    if req_env not in step_env and req_env not in job_env and req_env not in wf_env:
                        issues.append(f"Job `{job_id}` ({step_name}): `{b}` invocado sin inyectar credencial `{req_env}` desde `secrets.*`.")
    return issues


def _parse_kv_thresholds(arg_str: str) -> dict[str, int]:
    out = {}
    for part in filter(None, (p.strip() for p in arg_str.split(","))):
        m = re.match(r"(critical|high|medium|low)=(\d+)", part)
        if m:
            out[m.group(1)] = int(m.group(2))
    return out


def _resolve_input_defaults(doc: dict) -> dict[str, str]:
    """Obtiene los valores por defecto de `on.workflow_call.inputs` para resolver referencias en workflows reutilizables."""
    triggers = normalize_on_triggers(doc)
    wc = triggers.get("workflow_call") or {}
    inputs = wc.get("inputs") or {}
    defaults = {}
    for k, v in inputs.items():
        if isinstance(v, dict) and "default" in v:
            defaults[k] = str(v["default"])
    return defaults


def _resolve_rule_value(raw_val: str, step_env: dict, input_defaults: dict) -> str:
    """Si un flag usa una variable de entorno del step (ej. $SAST_RULES) mapeada a inputs.X, resuelve su default."""
    val = raw_val.strip()
    m_env = re.fullmatch(r"\$\{?([A-Za-z0-9_]+)\}?", val)
    if m_env and isinstance(step_env, dict):
        env_expr = str(step_env.get(m_env.group(1), ""))
        m_inp = re.search(r"inputs\.([A-Za-z0-9_-]+)", env_expr)
        if m_inp and m_inp.group(1) in input_defaults:
            return input_defaults[m_inp.group(1)]
    return val


def detect_gate_threshold_compliance(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    max_sev = params.get("max_allowed_severities_by_tier", {}).get(tier, {"critical": 0, "high": 0})
    min_cov = params.get("min_sonar_coverage_by_tier", {}).get(tier, 80)
    input_defaults = _resolve_input_defaults(doc)

    for job_id, _, steps in iter_jobs_and_steps(doc):
        for idx, step in enumerate(steps, 1):
            run_cmd = normalize_shell_continuations(step.get("run") or "")
            step_name = step.get("name") or f"step #{idx}"
            step_env = step.get("env") or {}

            # 1) Escáneres basados en --fail-on (fortify, checkmarx, burp)
            for scanner in ("fortify-mock", "checkmarx-mock", "burp-mock"):
                if scanner not in run_cmd:
                    continue
                m = re.search(rf"{scanner}[^\n]*?--fail-on\s+[\"']([^\"']+)[\"']", run_cmd)
                if not m:
                    m = re.search(rf"{scanner}[^\n]*?--fail-on\s+(\S+)", run_cmd)
                if not m:
                    issues.append(f"Job `{job_id}` ({step_name}): `{scanner}` invocado sin reglas `--fail-on` (gate vacío).")
                    continue
                resolved_arg = _resolve_rule_value(m.group(1), step_env, input_defaults)
                parsed = _parse_kv_thresholds(resolved_arg)
                for sev_key, limit_val in max_sev.items():
                    if sev_key not in parsed:
                        issues.append(
                            f"Job `{job_id}` ({step_name}): `{scanner}` no restringe severidad `{sev_key}` (máximo permitido en {tier}: {sev_key}<={limit_val})."
                        )
                    elif parsed[sev_key] > limit_val:
                        issues.append(
                            f"Job `{job_id}` ({step_name}): umbral permisivo `{sev_key}={parsed[sev_key]}` en `{scanner}` (máximo permitido en {tier}: {sev_key}<={limit_val})."
                        )

            # 2) SonarQube (--gate)
            if "sonar-scanner-mock" in run_cmd:
                m = re.search(r"sonar-scanner-mock[^\n]*?--gate\s+[\"']([^\"']+)[\"']", run_cmd)
                if not m:
                    m = re.search(r"sonar-scanner-mock[^\n]*?--gate\s+(\S+)", run_cmd)
                if not m:
                    issues.append(f"Job `{job_id}` ({step_name}): `sonar-scanner-mock` invocado sin `--gate` (gate vacío que nunca bloquea).")
                else:
                    gate_str = _resolve_rule_value(m.group(1), step_env, input_defaults)
                    cov_m = re.search(r"coverage>=(\d+(?:\.\d+)?)", gate_str)
                    if not cov_m or float(cov_m.group(1)) < min_cov:
                        issues.append(
                            f"Job `{job_id}` ({step_name}): `sonar-scanner-mock` debe exigir `coverage>={min_cov}` en `{tier}`."
                        )
                    if "bugs<=0" not in gate_str or "vulnerabilities<=0" not in gate_str:
                        issues.append(
                            f"Job `{job_id}` ({step_name}): `sonar-scanner-mock` debe exigir `bugs<=0` y `vulnerabilities<=0`."
                        )
    return issues


def detect_required_tier_gates(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    reqs = params.get("requirements_by_tier", {}).get(tier, {})
    all_runs = []
    uses_reusable_ci = False
    for _, job, steps in iter_jobs_and_steps(doc):
        if str(job.get("uses") or "").endswith("reusable-java-ci.yml"):
            uses_reusable_ci = True
        for s in steps:
            if s.get("run"):
                all_runs.append(normalize_shell_continuations(s["run"]))
    full_run_text = "\n".join(all_runs)

    has_sast = uses_reusable_ci or ("fortify-mock" in full_run_text) or bool(re.search(r"checkmarx-mock[^\n]*--engine\s+sast", full_run_text))
    has_sca = uses_reusable_ci or bool(re.search(r"checkmarx-mock[^\n]*--engine\s+sca", full_run_text)) or ("xray-scan" in full_run_text)
    has_sonar = uses_reusable_ci or ("sonar-scanner-mock" in full_run_text)

    if reqs.get("require_sast") and not has_sast:
        issues.append(f"Falta gate obligatorio de SAST (`fortify-mock` o `checkmarx-mock --engine sast`) requerido para `{tier}`.")
    if reqs.get("require_sca_explicit") and not has_sca:
        issues.append(f"Falta gate obligatorio de SCA (`checkmarx-mock --engine sca` o `jfrog-mock xray-scan`) requerido para `{tier}`.")
    if reqs.get("require_quality_or_sca") and not (has_sonar or has_sca):
        issues.append(f"Falta gate obligatorio de Calidad/Seguridad (`sonar-scanner-mock` o SCA) requerido para `{tier}`.")
    return issues


def detect_cd_deployment_controls(doc: dict, raw_text: str, tier: str, params: dict) -> list[str]:
    issues = []
    deploy_re = re.compile(params.get("deploy_command_regex", r"(kubectl\s+apply|helm\s+upgrade)"))
    for job_id, job, steps in iter_jobs_and_steps(doc):
        for idx, step in enumerate(steps, 1):
            run_cmd = normalize_shell_continuations(step.get("run") or "")
            if deploy_re.search(run_cmd):
                if not job.get("environment"):
                    issues.append(
                        f"Job `{job_id}` step #{idx} ejecuta despliegue productivo (`{deploy_re.search(run_cmd).group(0)}`) sin `environment:` de aprobación."
                    )
                if not job.get("needs"):
                    prior_runs = "\n".join(normalize_shell_continuations(s.get("run") or "") for s in steps[: idx - 1])
                    if "mvn" not in prior_runs and "test" not in prior_runs:
                        issues.append(
                            f"Job `{job_id}` step #{idx} despliega a producción sin etapa previa de pruebas (`needs:` o `mvn verify`)."
                        )
    return issues


DETECTORS = {
    "workflow_permissions": detect_workflow_permissions,
    "forbidden_triggers": detect_forbidden_triggers,
    "action_pinning": detect_action_pinning,
    "checkout_persist_credentials": detect_checkout_persist_credentials,
    "no_hardcoded_secrets": detect_no_hardcoded_secrets,
    "no_context_injection": detect_no_context_injection,
    "no_mutable_docker_tag": detect_no_mutable_docker_tag,
    "job_timeout": detect_job_timeout,
    "workflow_concurrency": detect_workflow_concurrency,
    "no_ignorable_gates": detect_no_ignorable_gates,
    "gate_threshold_compliance": detect_gate_threshold_compliance,
    "required_tier_gates": detect_required_tier_gates,
    "cd_deployment_controls": detect_cd_deployment_controls,
}


def load_exceptions(exceptions_path: Path, ref_date: date) -> tuple[dict[tuple[str, str], dict], list[dict]]:
    """Carga exceptions.yml, valida campos obligatorios (owner, reason, expires) y separa activas vs expiradas."""
    active_map = {}
    expired_list = []
    if not exceptions_path or not exceptions_path.exists():
        return active_map, expired_list

    data = yaml.safe_load(exceptions_path.read_text(encoding="utf-8")) or {}
    for exc in data.get("exceptions", []):
        owner = str(exc.get("owner") or "").strip()
        reason = str(exc.get("reason") or "").strip()
        expires_str = str(exc.get("expires") or "").strip()
        squad = str(exc.get("squad") or "").strip().lower()
        rule_id = str(exc.get("rule_id") or "").strip()

        if not (owner and reason and expires_str and squad and rule_id):
            expired_list.append({**exc, "status": "INVALID_FIELDS"})
            continue

        exp_date = date.fromisoformat(expires_str)
        if exp_date < ref_date:
            expired_list.append({**exc, "status": "EXPIRED", "expired_days_ago": (ref_date - exp_date).days})
        else:
            active_map[(squad, rule_id)] = {**exc, "status": "ACTIVE", "days_remaining": (exp_date - ref_date).days}
    return active_map, expired_list


def audit_workflow(
    wf_path: Path,
    policies: dict,
    active_exceptions: dict[tuple[str, str], dict],
    expired_exceptions: list[dict],
) -> dict:
    raw_text = wf_path.read_text(encoding="utf-8")
    doc = yaml.safe_load(raw_text) or {}
    squad, tier = extract_metadata_from_header(raw_text, wf_path, policies.get("squad_tiers", {}))

    findings = []
    for rule in policies.get("rules", []):
        rule_id = rule["id"]
        severity = rule.get("severity_by_tier", {}).get(tier, "INFO")
        detector_fn = DETECTORS[rule["detector"]]
        messages = detector_fn(doc, raw_text, tier, rule.get("params", {}))
        if not messages:
            continue

        exc = active_exceptions.get((squad, rule_id))
        exp_matches = [e for e in expired_exceptions if e.get("squad") == squad and e.get("rule_id") == rule_id]
        for msg in messages:
            if exc:
                findings.append({
                    "rule_id": rule_id,
                    "title": rule["title"],
                    "severity": "EXEMPTED",
                    "original_severity": severity,
                    "message": msg,
                    "exception": exc,
                })
            else:
                note = ""
                if exp_matches:
                    e0 = exp_matches[0]
                    note = f" [EXCEPCIÓN CADUCADA el {e0.get('expires')} ({e0.get('id')}, owner: {e0.get('owner')})]"
                findings.append({
                    "rule_id": rule_id,
                    "title": rule["title"],
                    "severity": severity,
                    "message": msg + note,
                })

    blocking_cnt = sum(1 for f in findings if f["severity"] == "BLOCKING")
    warning_cnt = sum(1 for f in findings if f["severity"] == "WARNING")
    exempted_cnt = sum(1 for f in findings if f["severity"] == "EXEMPTED")

    return {
        "file": wf_path.name,
        "squad": squad,
        "tier": tier,
        "passed": blocking_cnt == 0,
        "blocking_count": blocking_cnt,
        "warning_count": warning_cnt,
        "exempted_count": exempted_cnt,
        "findings": findings,
    }


def main():
    parser = argparse.ArgumentParser(description="Auditor de Políticas como Código por Tier para GitHub Actions")
    parser.add_argument("--workflows", type=Path, default=DEFAULT_WORKFLOWS, help="Directorio o archivo YAML a auditar")
    parser.add_argument("--policies", type=Path, default=DEFAULT_POLICIES, help="Catálogo declarativo policies.yml")
    parser.add_argument("--exceptions", type=Path, default=DEFAULT_EXCEPTIONS, help="Archivo de excepciones exceptions.yml")
    parser.add_argument("--as-of", type=str, default=date.today().isoformat(), help="Fecha de referencia ISO (YYYY-MM-DD)")
    parser.add_argument("--json-report", type=Path, default=None, help="Guardar reporte JSON estructurado")
    args = parser.parse_args()

    ref_date = date.fromisoformat(args.as_of)
    policies = yaml.safe_load(args.policies.read_text(encoding="utf-8"))
    active_exc, expired_exc = load_exceptions(args.exceptions, ref_date)

    if args.workflows.is_dir():
        wf_files = sorted(list(args.workflows.glob("*.yml")) + list(args.workflows.glob("*.yaml")))
    else:
        wf_files = [args.workflows]

    results = [audit_workflow(w, policies, active_exc, expired_exc) for w in wf_files]

    print("=" * 92)
    print(f"AUDITORÍA DE GOBIERNO DE PIPELINES (POLICY-AS-CODE) — Fecha ref: {ref_date.isoformat()}")
    print("=" * 92)
    print(f"{'Workflow':<22} | {'Squad':<12} | {'Tier':<6} | {'Estado':<8} | {'Bloqueantes':<11} | {'Avisos':<7} | {'Excepciones'}")
    print("-" * 92)
    for r in results:
        status = "PASS" if r["passed"] else "FAIL"
        print(f"{r['file']:<22} | {r['squad']:<12} | {r['tier']:<6} | {status:<8} | {r['blocking_count']:>11} | {r['warning_count']:>7} | {r['exempted_count']:>11}")
    print("-" * 92)

    if expired_exc:
        print("\n[!] EXCEPCIONES CADUCADAS / INVÁLIDAS DETECTADAS (NO APLICADAS -> FAIL-CLOSED):")
        for e in expired_exc:
            print(f"    x {e.get('id')} (squad={e.get('squad')}, rule={e.get('rule_id')}): caducó el {e.get('expires')} — owner: {e.get('owner')}")

    print("\nDETALLE DE HALLAZGOS POR SQUAD:")
    for r in results:
        status_icon = "[OK]" if r["passed"] else "[FAIL]"
        print(f"\n{status_icon} {r['squad']} ({r['tier']}) — {r['file']}")
        if not r["findings"]:
            print("    Sin violaciones ni avisos. Cumple íntegramente la política de su tier.")
        for f in r["findings"]:
            sev = f["severity"]
            print(f"    - [{sev:<8}] {f['rule_id']}: {f['message']}")
            if sev == "EXEMPTED":
                ex = f["exception"]
                print(f"                 ↳ Excepción vigente {ex['id']} hasta {ex['expires']} (owner: {ex['owner']} | motivo: {ex['reason']})")

    total_blocking = sum(r["blocking_count"] for r in results)
    failed_workflows = sum(1 for r in results if not r["passed"])

    if args.json_report:
        args.json_report.parent.mkdir(parents=True, exist_ok=True)
        args.json_report.write_text(
            json.dumps(
                {
                    "as_of": ref_date.isoformat(),
                    "total_workflows": len(results),
                    "failed_workflows": failed_workflows,
                    "total_blocking_violations": total_blocking,
                    "expired_exceptions": expired_exc,
                    "results": results,
                },
                indent=2,
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )

    print("\n" + "=" * 92)
    print(f"RESUMEN FINAL: {len(results) - failed_workflows}/{len(results)} workflows aprobados | {total_blocking} violaciones bloqueantes.")
    print("=" * 92)
    sys.exit(1 if total_blocking > 0 else 0)


if __name__ == "__main__":
    main()
