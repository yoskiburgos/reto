# Diagnóstico Organizacional y Roadmap DevSecOps a 12 Meses

**Organización:** Banca Digital Regulada (12 squads, ~85 ingenieros, presupuesto de plataforma: 6 FTE SRE/DevOps)  
**Respaldo cuantitativo:** Generado de forma reproducible por [`diagnostico/analyze_org.py`](./analyze_org.py) y [`diagnostico/metrics_summary.json`](./metrics_summary.json) a partir de `org-teams.csv`, `org-incidents.csv`, `org-contexto.md` y la auditoría técnica de `org-workflows/`.

---

## 1. Resumen Ejecutivo para el CIO

La organización no sufre un problema generalizado de velocidad ni de calidad, sino una **bimodalidad extrema ("dos velocidades")** que oculta riesgos sistémicos regulatorios y operativos bajo promedios engañosos:

1. **La Paradoja del Change Failure Rate (CFR < 15%):** Aunque el promedio simple de CFR entre los 12 squads es **14.50%** (y el CFR ponderado por volumen de despliegues es **9.81%**, con 6.18 despliegues fallidos sobre 63 despliegues semanales), esta cifra esconde que **4 squads con despliegue manual (`data-platform`, `reporting`, `ledger`, `mobile-ios`) promedian un CFR de 24.25%** y concentran el **100% de los incidentes Sev1 (6 de 6)** y el **67.39% de todas las horas de caída (130.0 h de 192.9 h)** realizando apenas el **9.52% de los despliegues (6 de 63/semana)**.
2. **Incumplimiento de Auditoría Trimestral (SAST/SCA) y "Security Theater":** Frente a la exigencia regulatoria de evidencia SAST/SCA en el **100% de los releases**, hoy solo **6 de 12 squads (50.0%)** declaran cobertura completa (**76.19% de los releases semanales**). Peor aún, la inspección de los pipelines reales (`org-workflows/`) demuestra que incluso squads que declaran cumplir (`catalog`, `search`) o están en migración (`reporting`) tienen **gates vacíos o deshabilitados** (`|| true`, `--fail-on "critical=50"`, SonarQube sin `--gate`), mientras que `ledger` (sistema contable Tier 0) despliega a producción con credenciales en texto plano (`Led9er-Pr0d-2023`), `permissions: write-all` y vulnerabilidad crítica `pull_request_target`.
3. **Objetivos de DR (RTO 4 h / RPO 15 min) Inalcanzables Hoy:** La arquitectura actual (un único clúster AKS mono-región sin DR probado) registra un **MTTR real en incidentes Sev1 de 7.17 horas** (máximo de **13.0 h** en `reporting` y **9.2 h** en `data-platform`). El **83.3% de los incidentes Sev1 (5 de 6)** y el **70.0% del total de incidentes (21 de 30)** exceden el RTO declarado de 4 horas.

---

## 2. Hallazgos y Brechas con Evidencia Cuantitativa

### 2.1 Contradicciones entre lo Declarado y la Evidencia Empírica

| Afirmación / Meta Organizacional | Realidad Cuantitativa (Datos + Workflows) | Impacto Organizacional y Regulatorio |
| :--- | :--- | :--- |
| **"Reducir el CFR global a < 15%"** | El CFR medio simple ya es **14.50%** y el ponderado por despliegues es **9.81%**, pero 4 squads (`data-platform` 31%, `reporting` 27%, `ledger` 24%, `mobile-ios` 15%) operan entre **15% y 31% de fallo**. | Si se mide como promedio global, el objetivo parece cumplido sin tocar los 4 squads que generan los **6 incidentes Sev1**. El objetivo correcto debe ser **CFR $\le 10\%$ global y ningún squad $> 15\%$**. |
| **"Evidencia SAST/SCA en el 100% de los releases"** | Por CSV: **50.0% de squads** (`yes`: 6, `partial`: 2, `no`: 4) y **76.19% de releases (48/63)**. Por inspección de YAML: solo `checkout` tiene gates reales; `catalog` usa `critical=50` y Sonar sin `--gate`; `reporting` usa `|| true`; `search` no ejecuta SAST/SCA. | **Riesgo de hallazgo mayor / sanción en auditoría trimestral.** La cobertura efectiva real con bloqueo válido en los 5 workflows auditados es del **20% (1 de 5)**. |
| **"RTO objetivo declarado: 4 h; RPO: 15 min"** | Clúster único AKS en 1 región sin DR probado. MTTR medio general: **6.43 h** (declarado: 5.42 h); MTTR en Sev1: **7.17 h**. **21 de 30 incidentes (70.0%)** superan 4 h. | Ante caída regional de Azure o corrupción de datos, la reconstrucción manual supera las 4 h y un backup por snapshot periódico sin archivado continuo de WAL incumple RPO $\le 15\text{ min}$ para banca (`ledger`/`payments`). |
| **"Duplicar frecuencia de despliegue (63 $\rightarrow$ 126/sem) sin subir Sev1"** | Los 5 squads en Jenkins despliegan **3.2 veces/sem** (CFR **16.80%**, Lead Time **7.32 d**) y los 2 sin pipeline **1.5 veces/sem** (CFR **23.00%**, Lead Time **13.50 d**), frente a **8.8 veces/sem** en GitHub Actions (CFR **8.80%**, Lead Time **2.64 d**). | Forzar el doble de despliegues en squads con deploy manual (`ledger`, `data-platform`, `reporting`) sin automatizar antes sus pruebas y CD **duplicaría los incidentes Sev1**, pues el 100% de los Sev1 provienen de cambios manuales y despliegues sin pruebas. |

### 2.2 Radiografía por Modo de Despliegue y Plataforma CI/CD

La segmentación estadística demuestra que **la automatización no compite con la estabilidad; la impulsa** (correlación entre frecuencia de despliegue y CFR: $r = -0.7776$; entre Lead Time y MTTR: $r = +0.9915$; entre Lead Time y CFR: $r = +0.9623$):

| Segmento | Squads | Deploys / sem (% total) | Lead Time Medio | CFR Medio (Simple / Pond.) | MTTR Medio | Incidentes Totales (% / Sev1) | Horas de Caída (% del total) | Certificaciones (DevOps + Cloud) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Deploy Auto (GHA)** (`checkout`, `payments`, `catalog`, `notifications`) | 4 | **41** (65.1%) | **1.80 d** | **7.50%** / 7.20% | **1.62 h** | 6 (20.0% / **0 Sev1**) | 34.2 h (17.7%) | **48** (25 + 23) |
| **Deploy Semi** (`search`, `identity`, `mobile-android`, `fraud`) | 4 | **16** (25.4%) | **4.90 d** | **11.75%** / 11.50% | **3.88 h** | 5 (16.7% / **0 Sev1**) | 28.7 h (14.9%) | **32** (18 + 14) |
| **Deploy Manual** (`ledger`, `reporting`, `mobile-ios`, `data-platform`) | 4 | **6** (9.5%) | **12.50 d** | **24.25%** / 23.67% | **10.75 h** | **19** (63.3% / **6 Sev1**) | **130.0 h (67.4%)** | **10** (5 + 5) |
| **Total / Global** | **12** | **63** (100%) | **6.40 d** | **14.50% / 9.81%** | **5.42 h** | **30** (100% / **6 Sev1**) | **192.9 h** (100%) | **90** (48 + 42) |

### 2.3 Análisis de Pareto de Incidentes (30 Incidentes, 192.9 Horas de Indisponibilidad)

| Causa Raíz | Incidentes (% del total) | Desglose Severidad (Sev1 / Sev2 / Sev3) | Horas Perdidas (% Downtime) | Duración Media | Acción Estructural que lo Elimina |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **`cambio manual en prod`** | **14 (46.7%)** | **4 Sev1** / 7 Sev2 / 3 Sev3 | **86.5 h (44.8%)** | 6.18 h | Revocar acceso humano de escritura en AKS prod (Zero-Touch Prod); CD exclusivo vía GitOps/GHA con OIDC. |
| **`deploy sin pruebas`** | **7 (23.3%)** | **2 Sev1** / 4 Sev2 / 1 Sev3 | **53.3 h (27.6%)** | 7.61 h | Branch protection + reusable workflows con `mvn verify` y gates obligatorios de cobertura y calidad. |
| **`secret expirado`** | **3 (10.0%)** | 0 Sev1 / 2 Sev2 / 1 Sev3 | **17.4 h (9.0%)** | 5.80 h | Federación OIDC (sin secretos estáticos en CI) + External Secrets Operator con rotación automática y alertas 14d antes. |
| **`config drift`** | **3 (10.0%)** | 0 Sev1 / 2 Sev2 / 1 Sev3 | **11.5 h (6.0%)** | 3.83 h | Reconciliación continua declarativa (ArgoCD con `selfHeal: true`) + validación de esquemas Helm/Kustomize en CI. |
| **`dependencia externa`** | **2 (6.7%)** | 0 Sev1 / 2 Sev2 / 0 Sev3 | **14.1 h (7.3%)** | 7.05 h | Timeouts agresivos, Circuit Breakers, reintentos con jitter y validación mediante Ingeniería del Caos (Tarea 3). |
| **`capacidad`** | **1 (3.3%)** | 0 Sev1 / 0 Sev2 / 1 Sev3 | **10.1 h (5.2%)** | 10.10 h | Pruebas de carga automáticas (`loadrunner-mock` con SLA bloqueante en Tier 0/1) + HPA y PodDisruptionBudgets. |

> **Conclusión clave del Pareto:** El **70.0% de los incidentes (21/30)**, el **72.5% del tiempo de caída (139.8 h)** y el **100% de los Sev1 (6/6)** se deben exclusivamente a **`cambio manual en prod`** y **`deploy sin pruebas`**. Ambos vectores se erradican bloqueando cambios manuales en el clúster y exigiendo despliegue automatizado con gates de prueba y seguridad.

### 2.4 Brecha de Capacidades y Talento ($r = -0.8403$ entre Certificaciones y CFR)

Existe una correlación inversa de **$r = -0.8403$** entre el número de ingenieros certificados (DevOps + Cloud) y el CFR del squad, y de **$r = +0.8639$** con la frecuencia de despliegue. Los 3 squads más críticos en siniestralidad (`data-platform`: 4 Sev1, 0 certs DevOps; `reporting`: 1 Sev1, 1 cert DevOps; `ledger`: 1 Sev1, 2 certs DevOps) carecen de músculo técnico en automatización. Por tanto, entregarles únicamente documentación fracasará: requieren **Golden Paths (workflows reutilizables listos para consumir)** y acompañamiento tipo *Enabling Team* (embebiendo 1 ingeniero de plataforma temporalmente).

---

## 3. Priorización de Squads y Secuencia de Intervención

Aplicando el índice compuesto de riesgo (`RiskScore` calculado en `analyze_org.py` combinando severidad de incidentes, CFR, criticidad de negocio/tier y brecha de auditoría):

| Prioridad | Squads Objetivo | Tier | RiskScore | Justificación Cuantitativa |
| :---: | :--- | :---: | :---: | :--- |
| **P0 (Meses 1–3)** | `ledger`, `data-platform`, `reporting` | Tier 0 / Tier 2 | **92.8 – 144.2** | Concentran **6 de 6 Sev1 (100%)**, **18 de 30 incidentes (60%)** y **124.4 h de caída (64.5%)**. Tienen `security_scanning = no`, `deploy_mode = manual` y `ledger` tiene vulnerabilidades críticas activas en su YAML (`pull_request_target` + password en claro). |
| **P1 (Meses 2–6)** | `catalog`, `search`, `mobile-android`, `mobile-ios` | Tier 1 / Tier 2 | **10.8 – 54.0** | Cierre urgente del **100% de cobertura SAST/SCA para la Auditoría Q1/Q2**: corregir gates falsos en `catalog`, añadir SAST/SCA en `search` y `mobile-android`, y crear pipeline CI/CD en GHA para `mobile-ios`. |
| **P2 (Meses 4–9)** | `identity`, `fraud` | Tier 0 / Tier 1 | **25.4 – 27.0** | Evacuar los últimos squads de Jenkins (`identity`, `fraud`) hacia GitHub Actions + promocionar de `semi` a `auto` con aprobaciones declarativas, permitiendo **apagar el controlador único de Jenkins en Q3**. |
| **P3 (Meses 7–12)** | `checkout`, `payments`, `notifications` | Tier 0 / Tier 2 | **13.6 – 17.4** | Ya operan en `auto` con GHA y alta madurez; el foco en ellos es DAST/Performance automatizado, rotación de secretos, pruebas de caos (Game Days) y DR multi-región. |

---

## 4. Roadmap Priorizado a 12 Meses (Restricción: 6 FTE de Plataforma)

### Fechas Críticas de Auditoría Regulatoria
- **Hito Auditoría Q1 (Fin Mes 3 / Semana 12):** 100% de los 12 squads con escaneo SAST y SCA activo y generando artefactos firmados de evidencia; remediación total de secretos expuestos y `pull_request_target` en `ledger`.
- **Hito Auditoría Q2 (Fin Mes 6 / Semana 24):** `policy-check.py` en modo bloqueante para el 100% de repositorios (0 gates con `|| true` o sin reglas); primer Drill de DR ejecutado y auditado con evidencia en `docs/evidencias/`.
- **Hito Auditoría Q3 (Fin Mes 9 / Semana 36):** Desmantelamiento definitivo de Jenkins (100% de ejecuciones en GitHub Actions con trazabilidad OIDC + Artifactory/Xray); 0 accesos humanos de escritura en AKS producción.
- **Hito Auditoría Q4 (Fin Mes 12 / Semana 48):** Certificación anual de resiliencia (Game Day trimestral + Failover DR automatizado con RPO $< 5\text{ min}$ vía streaming WAL y RTO $< 30\text{ min}$).

### Secuencia Trimestral y Asignación de los 6 FTE

| Trimestre | Iniciativa Clave | Impacto | Riesgo | Esfuerzo (FTE) | Entregable Verificable |
| :---: | :--- | :---: | :---: | :---: | :--- |
| **Q1 (M1–M3)** *Contención y Auditoría SAST/SCA* | 1. **Remediar `ledger`, `reporting`, `catalog`, `search`**: eliminar secretos en claro, fijar SHAs y activar `policy-check.py` en CI.<br>2. **Crear pipelines base GHA** (Golden Paths `workflow_call`) para `data-platform` y `mobile-ios`.<br>3. **Habilitar SAST/SCA en los 12 squads** antes de la Auditoría Q1.<br>4. **Hardening base K8s**: PDBs, probes, `preStop` y backups automatizados con WAL archiving. | Muy Alto | Alto | **6 FTE** (3 en Golden Paths/Sec, 2 embebidos en `ledger`/`data-platform`, 1 en K8s/DR) | 12/12 squads con SAST+SCA reportando evidencia; 0 vulnerabilidades bloqueantes en `policy-check.py` (Tier 0/1); reducción de incidentes por secreto expirado. |
| **Q2 (M4–M6)** *Erradicación de Cambios Manuales y DR* | 1. **Zero-Touch Prod en AKS**: revocar `kubectl apply` manual; implantar despliegue declarativo con `environment: production` y reconciliación GitOps.<br>2. **Migrar `ledger`, `reporting` y `search` de Jenkins a GHA**.<br>3. **Desplegar región DR pasiva/tibio (Warm Standby)** con CloudNativePG y ejecutar Drill #1 medido. | Muy Alto | Medio | **6 FTE** (2 en migración Jenkins, 2 en GitOps/AKS, 2 en DR/DB) | 0 cambios manuales en producción; `ledger` y `data-platform` pasan de `manual` a `semi`/`auto` con suite de humo obligatoria; Drill DR $< 30\text{ min}$. |
| **Q3 (M7–M9)** *Decomiso de Jenkins y Observabilidad AIOps* | 1. **Migrar `identity` y `fraud` de Jenkins a GHA** y apagar el controlador único de Jenkins.<br>2. **Integrar detector estacional de anomalías (`detect.py`)** en el pipeline de alertas de Prometheus/Alertmanager con supresión automática de ventanas de cambio.<br>3. **Primer Game Day de Ingeniería del Caos** en Tier 0 (`checkout`, `payments`, `ledger`). | Alto | Medio | **6 FTE** (2 decomiso Jenkins, 2 SRE/Anomalías, 2 Chaos/Enabling) | 100% squads en GHA (SPOF de Jenkins eliminado); MTTR global $< 2.5\text{ h}$; reducción de falsos positivos de alertas nocturnas/fin de semana en $> 80\%$. |
| **Q4 (M10–M12)** *Escala Continua y Excelencia Operativa* | 1. **Promoción de squads `semi` a `auto`** una vez alcanzada cobertura de pruebas $\ge 80\%$ y gates estables.<br>2. **Game Day inter-squad y simulacro Sev1 + Failover DR sin aviso previo**.<br>3. **Programa interno de certificación** (Champions DevSecOps por squad). | Alto | Bajo | **6 FTE** (2 Evolución Plataforma, 2 Resiliencia/Chaos, 2 Habilitación) | Frecuencia de despliegue global $\ge 126\text{ deploys/sem}$ ($2\times$); CFR $< 8\%$ ponderado ($< 12\%$ en todo squad); 0 Sev1 por cambios. |

---

## 5. Qué NO Haremos (Decisiones Explícitas de Descarte)

Con un equipo acotado a **6 FTE de plataforma** para dar soporte a 12 squads (~85 ingenieros), la disciplina estratégica exige descartar iniciativas que diluirían el foco:

1. **NO construiremos un Portal de Desarrollador Interno (IDP / Backstage custom) en los primeros 12 meses:** Mantener un frontend propio consumiría 1.5–2 FTE permanentes. En su lugar, entregaremos **plantillas de repositorio y workflows reutilizables (`workflow_call`) en GitHub Actions** que se consumen en 15 líneas de YAML.
2. **NO implementaremos arquitectura Multi-Cloud Activo-Activo en este ciclo anual:** Operar cargas transaccionales bancarias simultáneamente en Azure y AWS/GCP con consistencia fuerte excede la capacidad de 6 FTE y multiplica costos de red y licenciamiento (ver [`ADR-001`](../docs/adr/ADR-001-estrategia-multiregion-multicloud.md)). Adoptaremos **Multi-Región Activo-Pasivo (Warm Standby) dentro de la misma nube con backups inmutables cross-cloud**.
3. **NO exigiremos cobertura unitaria del 80% el Día 1 a los squads con madurez `low` (`ledger`, `reporting`, `data-platform`, `mobile-ios`) para entrar al pipeline:** Bloquear hoy a `data-platform` o `ledger` por no tener 80% de cobertura impediría automatizar sus despliegues y perpetuaría los cambios manuales en producción (causa del 100% de Sev1). Aplicaremos **ratcheting progresivo** (bloqueo inmediato de SAST/SCA críticos + tests de humo en Q1; umbral de cobertura en *código nuevo* $\ge 80\%$ y subida gradual del global con excepciones con caducidad en `exceptions.yml`).
4. **NO introduciremos un Service Mesh complejo (Istio/Linkerd enterprise) en Q1–Q3:** Los problemas actuales de resiliencia se deben a falta de `readinessProbe`, `PodDisruptionBudget`, timeouts de cliente y despliegues manuales, no a carencia de mTLS mesh. Resolveremos primero la higiene de Kubernetes base (Tarea 3).
5. **NO permitiremos que los 6 FTE de plataforma escriban ni mantengan los tests funcionales de los squads:** Plataforma provee el arnés, los mocks/entornos efímeros y el acompañamiento (*Enabling Team* durante 3 semanas por squad), pero la propiedad de las pruebas y de la calidad reside en cada squad.

---

## 6. OKRs y KRs Medibles (Línea Base vs Meta a 12 Meses)

### Objetivo 1: Erradicar los incidentes críticos inducidos por cambios y acelerar la entrega segura (DORA)
- **KR 1.1 (Change Failure Rate):** Reducir el CFR medio simple por squad de **14.50% a $\le 8.50\%$** (Q2: $\le 11.5\%$) y el CFR del cuartil inferior (`data-platform`, `reporting`, `ledger`, `mobile-ios`) de **24.25% a $\le 12.0\%$**, manteniendo ningún squad por encima del **15%**.
- **KR 1.2 (Frecuencia de Despliegue):** Incrementar el volumen total de despliegues productivos de **63 deploys/semana (media 5.25/squad) a $\ge 126\text{ deploys/semana}$ (media $\ge 10.5/\text{squad}$)**, logrando que los squads hoy manuales pasen de **1.5 deploys/sem a $\ge 6.0\text{ deploys/sem}$**.
- **KR 1.3 (Lead Time for Changes):** Reducir el Lead Time medio organizacional de **6.40 días (mediana 5.25 d) a $\le 2.20\text{ días}$ (mediana $\le 1.8\text{ d}$)**.
- **KR 1.4 (Incidentes Sev1 por Cambios):** Reducir los incidentes Sev1 originados por `cambio manual en prod` o `deploy sin pruebas` de **6 por periodo base (100% de los Sev1) a 0 en Q3–Q4**, eliminando el 100% de accesos humanos de escritura directa en AKS producción para el final de Q2.

### Objetivo 2: Garantizar cumplimiento continuo de Auditoría y Gobierno de Supply Chain (Zero-Trust CI/CD)
- **KR 2.1 (Cobertura Real SAST/SCA):** Pasar del **50.0% de squads (6/12) y 76.19% de releases (48/63)** con escaneo declarado al **100% de squads (12/12) y 100% de releases** ejecutando SAST + SCA con reglas bloqueantes verificadas por `supply-chain/policy-check.py` antes del cierre de **Q1 (Semana 12)**.
- **KR 2.2 (Estandarización de Plataforma):** Migrar los **5 squads en Jenkins (`search`, `identity`, `ledger`, `reporting`, `fraud`)** y los **2 sin pipeline (`mobile-ios`, `data-platform`)** a workflows reutilizables de GitHub Actions, pasando del **41.7% (5/12) al 100% (12/12)** al cierre de **Q3 (Semana 36)**.
- **KR 2.3 (Higiene de Secretos y Excepciones):** Reducir los incidentes por `secret expirado` de **3 (17.4 h de caída) a 0** mediante 100% de autenticación cloud vía OIDC y mantener el **100% de las excepciones de política (`exceptions.yml`) con caducidad $\le 30\text{ días}$ y 0 excepciones vencidas**.

### Objetivo 3: Demostrar Resiliencia Comprobada (DR y Caos) bajo Objetivos Reales
- **KR 3.1 (MTTR y Cumplimiento de RTO):** Reducir el MTTR real en incidentes Sev1 de **7.17 horas a $\le 1.50\text{ horas}$** y el porcentaje de incidentes que superan las 4 h de **70.0% (21/30) a $< 5.0\%$**.
- **KR 3.2 (DR Comprobado):** Ejecutar **4 simulacros trimestrales de Failover DR** automatizados (`dr/failover.sh` evolucionado a CloudNativePG cross-region), reduciendo el RPO efectivo en bases transaccionales Tier 0 de **$\ge 15\text{ min}$ (pérdida por snapshot) a $< 1\text{ min}$ (streaming WAL)** y el RTO medido a **$< 15\text{ min}$**.
- **KR 3.3 (Capacidad Técnica de los Squads):** Incrementar el total de certificaciones/acreditaciones prácticas internas en DevSecOps y Cloud de **90 (48 DevOps + 42 Cloud) a $\ge 150$**, asegurando al menos **4 ingenieros acreditados en cada uno de los 4 squads hoy rezagados (`data-platform`, `reporting`, `ledger`, `mobile-ios`)**.

---

## 7. Prevención de Gamificación de Métricas (Blindaje contra la Ley de Goodhart)

> *"Cuando una medida se convierte en un objetivo, deja de ser una buena medida."* — Si vinculamos bonos o evaluaciones al número de despliegues o al CFR aislado, los squads optimizarán el número destruyendo el valor de negocio.

Para evitar la manipulación de métricas, implementamos **5 controles cruzados (Métricas Pareadas deTensión y Auditoría Automática)**:

1. **Contra la inflación artificial de `deploys_per_week` (micro-commits triviales o cambios de espacios en blanco):**
   - *Control:* Sólo contabilizan despliegues a producción que estén vinculados a un issue válido de producto/ingeniería en Jira (`DEVOPS-XXX` verificado automáticamente en el pipeline con `jira-mock get`) y que modifiquen artefactos compilados (`src/`, esquemas o configuración de runtime, excluyendo `docs/` o `.md` vía `paths-ignore`). Además, se mide el **Lead Time de PR a Producción** y el **Delivery Throughput de historias de usuario**, no solo el conteo bruto de ejecuciones.
2. **Contra el ocultamiento o sub-clasificación de incidentes para maquillar el `Change Failure Rate` y el conteo de `Sev1`:**
   - *Control:* La apertura de incidentes Sev1/Sev2 y el cálculo de CFR **no dependen de declaración manual del squad**: se derivan automáticamente de la correlación entre eventos de despliegue en GitHub Actions/ArgoCD y: (a) rollbacks/hotfixes ejecutados en las 24 h posteriores, (b) violación del presupuesto de error (SLO Burn Rate en Prometheus) o (c) disparos del detector automático de anomalías (`anomaly/detect.py`).
3. **Contra el "Security Theater" en gates de calidad y seguridad (`|| true`, `--fail-on critical=50`, exclusión masiva de carpetas en SonarQube):**
   - *Control:* El auditor de políticas [`supply-chain/policy-check.py`](../supply-chain/policy-check.py) se ejecuta como *Required Status Check* a nivel de organización (GitHub Rulesets) gestionado por Plataforma (protegido por `CODEOWNERS`). Cualquier intento de relajar umbrales (`coverage<80`, `critical>0`), añadir `continue-on-error: true` o usar `|| true` rompe el build antes del merge.
4. **Contra el abuso de excepciones permanentes (`exceptions.yml`):**
   - *Control:* Toda excepción exige `owner`, `reason` y `expires` (máximo 30 días en Tier 1/2 y 14 días en Tier 0). Cuando `expires < fecha_actual`, `policy-check.py` ignora la excepción y **bloquea el pipeline automáticamente (Fail-Closed)**. Además, el número de excepciones activas por squad es visible en el dashboard mensual del CIO.
5. **Cultura Justa (Blameless Postmortems):**
   - *Control:* Penalizar a un squad por reportar un incidente incentiva el silencio. Se evalúa positivamente la **detección temprana (MTTD)**, el cumplimiento de los *action items* de postmortems en SLA y la participación activa en *Game Days* de Ingeniería del Caos.
