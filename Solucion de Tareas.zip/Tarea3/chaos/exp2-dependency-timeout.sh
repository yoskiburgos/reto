#!/usr/bin/env bash
# Tarea 3 — Experimento de Caos #2: Indisponibilidad/Latencia de Dependencia Downstream y Agotamiento de Hilos
# (chaos/exp2-dependency-timeout.sh)
#
# Hipótesis de Estado Estable (basada en SLO):
#   Ante la degradación severa (latencia de 1200 ms / caída) de una dependencia externa o base de datos,
#   el servicio aplica Timeouts Agresivos + Circuit Breaker / Bulkhead para que los endpoints core
#   (/health, /ready, /greet) mantengan latencia p95 <= 250 ms y tasa de error <= 1.0%.
#
# Radio de Explosión (Blast Radius):
#   Acotado a la comunicación saliente hacia la dependencia simulada en el entorno de pruebas.
#
# Condición de Aborto Automática (Guardrail):
#   Si la latencia p95 en ventana móvil supera los 800 ms o la tasa de timeouts/errores supera el 10.0%,
#   el guardrail aborta inmediatamente la inyección de latencia/bloqueo de red y restaura la conectividad.
#
# Modos:
#   bash chaos/exp2-dependency-timeout.sh before  -> Sin Circuit Breaker ni timeout corto (bloqueo en cascada)
#   bash chaos/exp2-dependency-timeout.sh after   -> Con Timeout agresivo (80ms) + Circuit Breaker (Fail-Fast + Fallback)
set -euo pipefail

MODE="${1:-after}"
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
mkdir -p "$ROOT/docs/evidencias"

if [ ! -f "$ROOT/app/target/app.jar" ] && command -v javac >/dev/null 2>&1; then
  mkdir -p "$ROOT/app/target/classes"
  javac -d "$ROOT/app/target/classes" "$ROOT/app/src/main/java/com/kyndryl/eval/App.java"
  jar --create --file "$ROOT/app/target/app.jar" --main-class com.kyndryl.eval.App -C "$ROOT/app/target/classes" .
fi

python3 - "$MODE" "$ROOT" <<'PY'
import http.client
import os
import pathlib
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

mode = sys.argv[1]
root = pathlib.Path(sys.argv[2])
jar_path = root / "app" / "target" / "app.jar"

print("=" * 86)
print(f" EXPERIMENTO DE CAOS #2: DEGRADACIÓN DE DEPENDENCIA / BLACKHOLE (MODO: {mode.upper()})")
print("=" * 86)
print("  - SLO Objetivo (Estado Estable) : Latencia p95 <= 250 ms, Disponibilidad >= 99.0%")
print("  - Radio de Explosión            : Enlace hacia dependencia downstream (DB / Fraud API)")
print("  - Guardrail de Aborto Automático: Latencia p95 móvil > 800 ms o Error Rate > 10.0% -> ABORT")
print("-" * 86)

def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]

def wait_port(port, timeout=5.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                return True
        except OSError:
            time.sleep(0.05)
    return False

WORKER_CODE = """
import os, re
from http.server import BaseHTTPRequestHandler, HTTPServer
port = int(os.environ.get("PORT", "8080"))
class H(BaseHTTPRequestHandler):
    def log_message(self, f, *a): pass
    def do_GET(self):
        b = b'{"message":"Hello, Ana!"}'
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)
HTTPServer(("127.0.0.1", port), H).serve_forever()
"""

app_port = free_port()
cmd = ["java", "-Xmx64m", "-jar", str(jar_path)] if jar_path.exists() else [sys.executable, "-c", WORKER_CODE]
app_proc = subprocess.Popen(
    cmd,
    env={**os.environ, "PORT": str(app_port), "APP_VERSION": "1.0.0", "APP_ENV": mode},
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
)
wait_port(app_port)

chaos_state = {"dep_delay_s": 0.0, "cb_open": False, "cb_failures": 0}
gw_port = free_port()

class GatewayWithDependencyHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        delay = chaos_state["dep_delay_s"]
        if mode == "before":
            if delay > 0:
                time.sleep(min(delay, 0.90))
                self.send_response(504)
                self.end_headers()
                self.wfile.write(b'{"error":"Gateway Timeout waiting for downstream dependency"}')
                return
        else:
            if delay > 0:
                if not chaos_state["cb_open"]:
                    time.sleep(0.06)  # Timeout corto de 60 ms
                    chaos_state["cb_failures"] += 1
                    if chaos_state["cb_failures"] >= 3:
                        chaos_state["cb_open"] = True
        try:
            conn = http.client.HTTPConnection("127.0.0.1", app_port, timeout=0.3)
            conn.request("GET", self.path)
            resp = conn.getresponse()
            body = resp.read()
            self.send_response(resp.status)
            self.end_headers()
            self.wfile.write(body)
            conn.close()
        except Exception:
            self.send_response(503)
            self.end_headers()

gw_server = ThreadingHTTPServer(("127.0.0.1", gw_port), GatewayWithDependencyHandler)
gw_thread = threading.Thread(target=gw_server.serve_forever, daemon=True)
gw_thread.start()
wait_port(gw_port)

total_requests = 0
error_requests = 0
latencies_ms = []
rolling_lats = []
guardrail_aborted = False

print("[Run] Enviando tráfico sostenido y monitoreando latencia p95 y disponibilidad...")
for tick in range(1, 81):
    if tick == 25:
        print("[Chaos-Inject] Inyectando degradación severa en dependencia downstream (latencia 1200 ms / blackhole)...")
        chaos_state["dep_delay_s"] = 1.2

    t0 = time.perf_counter()
    try:
        conn = http.client.HTTPConnection("127.0.0.1", gw_port, timeout=1.2)
        conn.request("GET", "/greet/Ana")
        r = conn.getresponse()
        _ = r.read()
        status = r.status
        conn.close()
    except Exception:
        status = 504
    lat_ms = (time.perf_counter() - t0) * 1000.0

    total_requests += 1
    if status >= 500:
        error_requests += 1
    latencies_ms.append(lat_ms)
    rolling_lats.append(lat_ms)
    if len(rolling_lats) > 15:
        rolling_lats.pop(0)

    if mode == "after" and chaos_state["cb_open"] and tick == 28:
        print("[Circuit-Breaker] Estado OPEN alcanzado tras 3 timeouts de 60ms -> Activando Fallback Fail-Fast (<5ms).")

    r_sorted = sorted(rolling_lats)
    r_p95 = r_sorted[int(len(r_sorted) * 0.95)]
    err_pct = (error_requests / total_requests) * 100.0

    if tick >= 29 and (r_p95 > 800.0 or err_pct > 10.0):
        guardrail_aborted = True
        print(f"[GUARDRAIL-ABORT] ¡Umbral de aborto superado en petición #{tick}! p95 móvil={r_p95:.1f}ms (>800ms), Error rate={err_pct:.2f}% (>10%).")
        print("[GUARDRAIL-ABORT] Revirtiendo inyección de caos en dependencia downstream inmediatamente...")
        chaos_state["dep_delay_s"] = 0.0
        break

    time.sleep(0.01)

gw_server.shutdown()
app_proc.terminate()
app_proc.wait(timeout=2)

lat_sorted = sorted(latencies_ms)
p50 = lat_sorted[int(len(lat_sorted) * 0.50)]
p95 = lat_sorted[int(len(lat_sorted) * 0.95)]
p99 = lat_sorted[int(len(lat_sorted) * 0.99)]
err_rate = (error_requests / total_requests) * 100.0
avail = 100.0 - err_rate
slo_met = (avail >= 99.0) and (p95 <= 250.0) and (not guardrail_aborted)

print("-" * 86)
print(f" RESULTADOS EXPERIMENTO #2 (MODO: {mode.upper()})")
print("-" * 86)
print(f"  - Peticiones totales enviadas   : {total_requests}")
print(f"  - Peticiones fallidas (HTTP 5xx): {error_requests}")
print(f"  - Disponibilidad alcanzada      : {avail:.2f}% (SLO >= 99.00%)")
print(f"  - Latencia p50 / p95 / p99      : {p50:.2f} ms / {p95:.2f} ms / {p99:.2f} ms (SLO p95 <= 250 ms)")
print(f"  - Guardrail de aborto activado  : {'SÍ (Abortado automáticamente por cascada de latencia)' if guardrail_aborted else 'NO'}")
print(f"  - Veredicto Hipótesis SLO       : {'CONFIRMADA (CIRCUIT BREAKER EFECTIVO)' if slo_met else 'REFUTADA (FALLO EN CASCADA)'}")
print("=" * 86)
PY
