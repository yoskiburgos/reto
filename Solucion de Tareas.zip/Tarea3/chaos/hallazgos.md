# Hallazgos de Ingeniería del Caos y Plan de Game Day (`chaos/hallazgos.md`)

**Evidencia de ejecución:** [`docs/evidencias/tarea3-chaos-experiments.log`](../docs/evidencias/tarea3-chaos-experiments.log)  
**Manifiestos evaluados:** [`chaos/k8s/app-vulnerable.yaml`](./k8s/app-vulnerable.yaml) (Antes) $\rightarrow$ [`chaos/k8s/app-resilient.yaml`](./k8s/app-resilient.yaml) (Después)

---

## 1. Diseño y Resultados de los 2 Experimentos de Caos

### Experimento 1: Terminación Abrupta de Instancia/Pod bajo Tráfico Sostenido ([`chaos/exp1-pod-kill.sh`](./exp1-pod-kill.sh))

- **Hipótesis de Estado Estable (basada en SLO):** Mientras el servicio `devops-app` procesa tráfico continuo a `/greet/{name}`, la pérdida súbita de 1 pod/instancia (`SIGKILL` / `kubectl delete pod --grace-period=0` o desalojo de nodo) no debe degradar la disponibilidad por debajo del **SLO de 99.50%** (tasa de error HTTP 5xx $\le 0.50\%$) ni elevar la latencia **$p95 > 250\text{ ms}$**.
- **Radio de Explosión (Blast Radius):** Acotado estrictamente a **1 pod** del deployment `devops-app` dentro del namespace `app` (máximo 33% de la flota en configuración de 3 réplicas).
- **Condición de Aborto Automática (Guardrail):** El controlador del experimento monitorea en cada petición la tasa de error acumulada y de ventana móvil; si `error_rate > 5.0%`, **aborta inmediatamente la prueba y lanza la recuperación de emergencia del pod**.

| Métrica | Ejecución Inicial (`before` — `app-vulnerable.yaml`) | Repetición Post-Remediación (`after` — `app-resilient.yaml`) | Umbral SLO / Guardrail |
| :--- | :---: | :---: | :---: |
| **Configuración del Servicio** | `replicas: 1`, sin `PDB`, sin `readinessProbe` ni `preStop` hook | `replicas: 3`, `PDB (minAvailable: 2)`, `readinessProbe (2s)`, `preStop (sleep 5)` | — |
| **Disponibilidad Alcanzada** | **90.70%** (4 fallos en 43 reqs) | **100.00%** (0 fallos en 120 reqs) | **SLO $\ge 99.50\%$** |
| **Tasa de Error HTTP 5xx** | **9.30%** | **0.00%** | **SLO $\le 0.50\%$** |
| **Latencia $p50$ / $p95$ / $p99$** | 4.38 ms / 6.26 ms / 6.92 ms | 4.51 ms / **6.11 ms** / 7.75 ms | **SLO $p95 \le 250\text{ ms}$** |
| **Guardrail de Aborto (`> 5%`)** | **ACTIVADO en petición #43** (Auto-rollback ejecutado) | **NO ACTIVADO** | Aborto si Error $> 5.0\%$ |
| **Veredicto** | **HIPÓTESIS REFUTADA** | **HIPÓTESIS CONFIRMADA** | — |

**Hallazgo Real #1 y Remediación Aplicada:**  
En la configuración inicial, además del punto único de fallo (`replicas: 1`), cuando Kubernetes envía `SIGTERM` a un pod, la actualización asíncrona de `EndpointSlices` e `iptables`/`IPVS` en `kube-proxy` ocurre en paralelo al cierre del proceso Java, por lo que el balanceador sigue enviando tráfico durante 1–3 segundos a un socket cerrado. En `chaos/k8s/app-resilient.yaml` se corrigió mediante:
1. **`replicas: 3` + `PodDisruptionBudget (minAvailable: 2)` + `maxUnavailable: 0`** en `rollingUpdate`.
2. **`lifecycle.preStop: ["sleep", "5"]`** combinado con `readinessProbe` cada 2 s: permite que Kubernetes retire la IP del pod de los endpoints activos **antes** de que el proceso JVM deje de aceptar conexiones en vuelo (*Zero-Downtime Graceful Drain*).

---

### Experimento 2: Degradación Severa / Blackhole en Dependencia Externa ([`chaos/exp2-dependency-timeout.sh`](./exp2-dependency-timeout.sh))

- **Hipótesis de Estado Estable (basada en SLO):** Motivado por los datos reales de `org-incidents.csv` (donde `dependencia externa` causó 2 incidentes Sev2 con **14.1 horas de caída** en `fraud` y `mobile-android`), postulamos que ante una latencia de $1200\text{ ms}$ o caída de una dependencia downstream, el servicio debe mantener una disponibilidad **$\ge 99.00\%$** y una latencia **$p95 \le 250\text{ ms}$** mediante *Timeouts Agresivos* y *Circuit Breaking*.
- **Radio de Explosión (Blast Radius):** Acotado al enlace de red/cliente HTTP hacia la dependencia downstream simulada.
- **Condición de Aborto Automática (Guardrail):** Si la latencia móvil $p95$ supera **$800\text{ ms}$** o la tasa de errores HTTP 5xx supera el **$10.0\%$**, el script revierte de inmediato la inyección de latencia.

| Métrica | Ejecución Inicial (`before` — Sin Circuit Breaker) | Repetición Post-Remediación (`after` — Con Timeout 60ms + Circuit Breaker) | Umbral SLO / Guardrail |
| :--- | :---: | :---: | :---: |
| **Disponibilidad Alcanzada** | **82.76%** (5 timeouts 504 en 29 reqs) | **100.00%** (0 errores en 80 reqs) | **SLO $\ge 99.00\%$** |
| **Latencia $p50$ / $p95$ / $p99$** | 4.41 ms / **904.41 ms** / 904.43 ms | 4.60 ms / **5.82 ms** / 66.42 ms | **SLO $p95 \le 250\text{ ms}$** |
| **Guardrail de Aborto** | **ACTIVADO en petición #29** ($p95 = 904.4\text{ ms} > 800\text{ ms}$) | **NO ACTIVADO** (Circuit Breaker abre en req #28) | Aborto si $p95 > 800\text{ ms}$ |
| **Veredicto** | **HIPÓTESIS REFUTADA (Cascading Failure)** | **HIPÓTESIS CONFIRMADA** | — |

**Hallazgo Real #2 y Remediación Aplicada:**  
Sin un timeout de cliente menor que el SLA del llamador ni un *Circuit Breaker*, una dependencia lenta bloquea los hilos del servidor HTTP (`Executors`), provocando agotamiento de pool y fallo en cascada (`HTTP 504`). Al instrumentar un **timeout estricto de 60 ms** y un **Circuit Breaker con umbral de 3 fallos consecutivos** que pasa a estado `OPEN` devolviendo respuesta degradada (*Fail-Fast Fallback* en `< 5 ms`), el $p99$ se contuvo en **66.42 ms** (los 3 intentos iniciales antes de abrir el circuito) y el $p95$ permaneció en **5.82 ms** con **100% de disponibilidad**.

---

## 2. Plan de *Game Day* Organizacional (Banca Digital — Trimestral)

### 2.1 Objetivos y Alcance
Validar en condiciones reales la resiliencia técnica de los servicios **Tier 0 (`checkout`, `payments`, `ledger`, `fraud`)** y la respuesta humana coordinada bajo el protocolo de *Incident Command System (ICS)* antes de cada auditoría trimestral.

### 2.2 Roles y Responsabilidades (Rotativos entre Squads)
| Rol | Responsable | Función Durante el Game Day |
| :--- | :--- | :--- |
| **Incident Commander (IC)** | Tech Lead / SRE de guardia | Autoridad única de decisión, priorización de mitigaciones y activación del botón rojo de aborto (*Kill Switch*). |
| **Chaos Operator (Red Team)** | Ingeniero de Plataforma SRE | Ejecuta los scripts de inyección (`chaos/exp1-pod-kill.sh`, `chaos/exp2-dependency-timeout.sh`, `dr/failover.sh`) y vigila los guardrails automáticos. |
| **Observability & Blue Team** | Ingenieros del Squad evaluado | Monitorean dashboards de Prometheus, alertas de `anomaly/detect.py`, logs de aplicación y ejecutan el runbook de diagnóstico/mitigación. |
| **Scribe (Cronista)** | Ingeniero invitado de otro squad | Registra con marca de tiempo UTC cada síntoma, alerta disparada, comando ejecutado y calcula **MTTD** (tiempo hasta detectar) y **MTTR** (tiempo hasta recuperar). |

### 2.3 Pre-requisitos y Guardrails de Seguridad ("Go / No-Go Checklist")
1. **Ventana acordada y sin incidentes activos:** No se inicia ningún Game Day si hay un incidente Sev1/Sev2 abierto en producción o durante cierre contable bancario.
2. **Registro en `eventos.csv` / Calendario de Cambios:** La ventana se registra formalmente para auditar que el flujo de supresión o alerta opere según lo diseñado.
3. **Kill Switch Automatizado y Manual:** Todo experimento tiene un `timeout` duro de 10 minutos y un comando de reversión de 1 línea (`kubectl apply -f chaos/k8s/app-resilient.yaml`). Si el consumo del *Error Budget* mensual supera el 2% durante el ejercicio, se aborta de inmediato.

### 2.4 Agenda Cronometrada del Game Day (90 Minutos)
- **00:00 – 00:15 (Briefing y Verificación de Estado Estable):** Revisión de hipótesis SLO, confirmación de métricas base en Prometheus (`/metrics`) y validación de backups recientes en `dr/backups/`.
- **00:15 – 00:35 (Escenario 1 — Fallo de Infraestructura / Nodo y Pods en `checkout`):** Ejecución de `exp1-pod-kill.sh` y drenado simulado de nodo. Meta: MTTD $< 2\text{ min}$, impacto en clientes $= 0\%$.
- **00:35 – 00:55 (Escenario 2 — Latencia en Dependencia de Fraude/Pagos):** Ejecución de `exp2-dependency-timeout.sh`. Verificación de apertura del Circuit Breaker y alerta en Prometheus sin degradar `checkout`.
- **00:55 – 01:15 (Escenario 3 — Conmutación DR de Base de Datos):** Ejecución cronometrada de `dr/failover.sh` y validación de RPO/RTO reales frente al objetivo del ADR-002.
- **01:15 – 01:30 (Debriefing en Caliente y Asignación de Action Items):** Revisión de tiempos MTTD/MTTR registrados por el *Scribe* y creación de tickets `DEVOPS-XXX` en Jira con SLA de remediación $< 14\text{ días}$.
