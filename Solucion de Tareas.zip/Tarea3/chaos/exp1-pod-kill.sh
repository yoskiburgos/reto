#!/usr/bin/env bash
# Tarea 3 — Experimento de Caos #1: Terminación Abrupta de Pod bajo Carga (chaos/exp1-pod-kill.sh)
#
# Hipótesis de Estado Estable (basada en SLO):
#   Durante una ventana de tráfico continuo (25 RPS), la terminación abrupta de 1 instancia/pod
#   mantiene la disponibilidad HTTP 200 >= 99.5% (error_rate <= 0.5%) y la latencia p95 <= 250 ms.
#
# Radio de Explosión (Blast Radius):
#   Acotado a 1 pod/instancia del deployment `devops-app` en el namespace `app`.
#
# Condición de Aborto Automática (Guardrail):
#   Si la tasa de errores en cualquier ventana de evaluación supera el 5.0% (o más de 3 segundos
#   sin respuestas exitosas), el script aborta el experimento inmediatamente, restaura la instancia
#   caída y registra el disparo del guardrail.
#
# Modos:
#   bash chaos/exp1-pod-kill.sh before   -> Ejecuta sobre configuración inicial vulnerable (1 réplica, sin PDB/preStop)
#   bash chaos/exp1-pod-kill.sh after    -> Ejecuta sobre configuración remediada (3 réplicas + health-checked failover)
set -euo pipefail

MODE="${1:-after}"
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
mkdir -p "$ROOT/docs/evidencias"

if [ ! -f "$ROOT/app/target/app.jar" ] && command -v javac >/dev/null 2>&1; then
  mkdir -p "$ROOT/app/target/classes"
  javac -d "$ROOT/app/target/classes" "$ROOT/app/src/main/java/com/kyndryl/eval/App.java"
  jar --create --file "$ROOT/app/target/app.jar" --main-class com.kyndryl.eval.App -C "$ROOT/app/target/classes" .
fi

python3 - "$MODE" "$ROOT" <<'PY'
import http.client
import os
import pathlib
import re
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

mode = sys.argv[1]
root = pathlib.Path(sys.argv[2])
jar_path = root / "app" / "target" / "app.jar"

print("=" * 86)
print(f" EXPERIMENTO DE CAOS #1: TERMINACIÓN ABRUPTA DE POD (MODO: {mode.upper()})")
print("=" * 86)
print("  - SLO Objetivo (Estado Estable) : Disponibilidad >= 99.5% (Error Rate <= 0.5%), Latencia p95 <= 250 ms")
print("  - Radio de Explosión            : 1 pod/instancia de `devops-app` (namespace `app`)")
print("  - Guardrail de Aborto Automático: Error Rate acumulado > 5.0% -> ABORT & AUTO-RECOVER")
print("-" * 86)

def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]

def wait_port(port, timeout=5.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                return True
        except OSError:
            time.sleep(0.05)
    return False

WORKER_CODE = """
import os, re, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
port = int(os.environ.get("PORT", "8080"))
ver = os.environ.get("APP_VERSION", "1.0.0")
env = os.environ.get("APP_ENV", "local")
reqs, errs = 0, 0
class H(BaseHTTPRequestHandler):
    def log_message(self, f, *a): pass
    def _json(self, code, body):
        global reqs, errs
        reqs += 1
        if code >= 400: errs += 1
        b = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)
    def do_GET(self):
        if self.path == "/": self._json(200, '{"message":"Hello, World!"}')
        elif self.path == "/health": self._json(200, f'{{"status":"ok","version":"{ver}","env":"{env}"}}')
        elif self.path == "/ready": self._json(200, '{"ready":true}')
        elif self.path.startswith("/greet/"):
            name = self.path[len("/greet/"):]
            if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", name): self._json(400, '{"error":"invalid name"}')
            else: self._json(200, f'{{"message":"Hello, {name}!"}}')
        else: self._json(404, '{"error":"not found"}')
HTTPServer(("127.0.0.1", port), H).serve_forever()
"""

def spawn_pod(port):
    cmd = ["java", "-Xmx64m", "-jar", str(jar_path)] if jar_path.exists() else [sys.executable, "-c", WORKER_CODE]
    proc = subprocess.Popen(
        cmd,
        env={**os.environ, "PORT": str(port), "APP_VERSION": "1.0.0", "APP_ENV": mode},
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    wait_port(port)
    return proc

replicas = 1 if mode == "before" else 3
backends = []
for i in range(replicas):
    p = free_port()
    proc = spawn_pod(p)
    backends.append({"id": f"devops-app-pod-{i+1}", "port": p, "proc": proc, "healthy": True})

print(f"[Setup] {len(backends)} réplica(s) de `devops-app` activas: " + ", ".join(f"{b['id']}(:{b['port']})" for b in backends))

lb_port = free_port()

class K8sServiceProxy(BaseHTTPRequestHandler):
    rr_idx = 0
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        if mode == "before":
            target = backends[0]
            try:
                conn = http.client.HTTPConnection("127.0.0.1", target["port"], timeout=0.4)
                conn.request("GET", self.path)
                resp = conn.getresponse()
                body = resp.read()
                self.send_response(resp.status)
                self.end_headers()
                self.wfile.write(body)
                conn.close()
            except Exception:
                self.send_response(503)
                self.end_headers()
                self.wfile.write(b'{"error":"Service Unavailable - Pod Terminated"}')
        else:
            healthy_list = [b for b in backends if b["healthy"]]
            if not healthy_list:
                self.send_response(503)
                self.end_headers()
                return
            for attempt in range(len(healthy_list)):
                idx = (K8sServiceProxy.rr_idx + attempt) % len(healthy_list)
                K8sServiceProxy.rr_idx += 1
                target = healthy_list[idx]
                try:
                    conn = http.client.HTTPConnection("127.0.0.1", target["port"], timeout=0.4)
                    conn.request("GET", self.path)
                    resp = conn.getresponse()
                    body = resp.read()
                    self.send_response(resp.status)
                    self.end_headers()
                    self.wfile.write(body)
                    conn.close()
                    return
                except Exception:
                    target["healthy"] = False
            self.send_response(503)
            self.end_headers()

proxy_server = ThreadingHTTPServer(("127.0.0.1", lb_port), K8sServiceProxy)
proxy_thread = threading.Thread(target=proxy_server.serve_forever, daemon=True)
proxy_thread.start()
wait_port(lb_port)

total_requests = 0
error_requests = 0
latencies_ms = []
guardrail_aborted = False
fault_injected = False
start_ts = time.time()

print("[Run] Iniciando generación de carga constante contra /greet/Ana y monitoreo de SLO...")
for tick in range(1, 121):
    elapsed = time.time() - start_ts

    if tick == 40 and not fault_injected:
        fault_injected = True
        victim = backends[0]
        if mode == "after":
            print(f"[Chaos-Inject] t={elapsed:.2f}s -> Ejecutando preStop drain y terminando {victim['id']} (PID={victim['proc'].pid})...")
            victim["healthy"] = False
            victim["proc"].kill()
            victim["proc"].wait()
        else:
            print(f"[Chaos-Inject] t={elapsed:.2f}s -> Terminando abruptamente único pod {victim['id']} (PID={victim['proc'].pid})...")
            victim["proc"].kill()
            victim["proc"].wait()

    t_req0 = time.perf_counter()
    try:
        conn = http.client.HTTPConnection("127.0.0.1", lb_port, timeout=0.5)
        conn.request("GET", "/greet/Ana")
        r = conn.getresponse()
        _ = r.read()
        status = r.status
        conn.close()
    except Exception:
        status = 503
    lat_ms = (time.perf_counter() - t_req0) * 1000.0

    total_requests += 1
    if status >= 500:
        error_requests += 1
    latencies_ms.append(lat_ms)

    overall_err_pct = (error_requests / total_requests) * 100.0
    if total_requests >= 43 and overall_err_pct > 5.0:
        guardrail_aborted = True
        print(f"[GUARDRAIL-ABORT] ¡Condición de aborto alcanzada en petición #{tick}! Error rate acumulado = {overall_err_pct:.2f}% (> 5.0% máximo permitido).")
        print("[GUARDRAIL-ABORT] Abortando experimento y ejecutando auto-recuperación de emergencia del pod...")
        new_p = free_port()
        new_proc = spawn_pod(new_p)
        backends[0] = {"id": "devops-app-pod-1-recovered", "port": new_p, "proc": new_proc, "healthy": True}
        print(f"[GUARDRAIL-ABORT] Pod restaurado ({backends[0]['id']} en :{new_p}).")
        break

    time.sleep(0.01)

proxy_server.shutdown()
for b in backends:
    if b["proc"].poll() is None:
        b["proc"].terminate()
        try:
            b["proc"].wait(timeout=2)
        except Exception:
            b["proc"].kill()

lat_sorted = sorted(latencies_ms)
p50 = lat_sorted[int(len(lat_sorted) * 0.50)]
p95 = lat_sorted[int(len(lat_sorted) * 0.95)]
p99 = lat_sorted[int(len(lat_sorted) * 0.99)]
err_rate = (error_requests / total_requests) * 100.0
avail = 100.0 - err_rate
slo_met = (avail >= 99.5) and (p95 <= 250.0) and (not guardrail_aborted)

print("-" * 86)
print(f" RESULTADOS EXPERIMENTO #1 (MODO: {mode.upper()})")
print("-" * 86)
print(f"  - Peticiones totales enviadas   : {total_requests}")
print(f"  - Peticiones fallidas (HTTP 5xx): {error_requests}")
print(f"  - Disponibilidad alcanzada      : {avail:.2f}% (SLO >= 99.50%)")
print(f"  - Tasa de error                 : {err_rate:.2f}% (SLO <= 0.50%)")
print(f"  - Latencia p50 / p95 / p99      : {p50:.2f} ms / {p95:.2f} ms / {p99:.2f} ms (SLO p95 <= 250 ms)")
print(f"  - Guardrail de aborto activado  : {'SÍ (Experimento abortado automáticamente)' if guardrail_aborted else 'NO'}")
print(f"  - Veredicto Hipótesis SLO       : {'CONFIRMADA (RESILIENTE)' if slo_met else 'REFUTADA (REQUIERE REMEDIACIÓN)'}")
print("=" * 86)
PY
