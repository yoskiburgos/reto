# Postmortem Sin Culpa (Blameless Postmortem) — Simulacro de Incidente Sev1 (`docs/postmortem-simulacro-sev1.md`)

- **ID del Incidente:** `INC-SIM-2026-001` (Simulacro de Incidente Sev1 — Degradación Crítica en Pagos y Libro Mayor)
- **Fecha y Ventana UTC:** `2026-10-16 18:00:00Z` – `2026-10-16 18:24:00Z` (Duración total: **24 minutos**)
- **Severidad:** **Sev1** (Impacto en transacciones de `payments` y `ledger` — Tier 0)
- **Incident Commander (IC):** Referente Técnico DevSecOps Master
- **Estado:** Resuelto y Acciones Preventivas Comprometidas

---

## 1. Resumen Ejecutivo e Impacto

Durante un despliegue en horario pico sobre el servicio contable `ledger` (Tier 0), un cambio aplicado sin validación previa de carga ni límites de conexión agotó el pool de conexiones de PostgreSQL en el clúster primario, provocando un aumento de la tasa de error al **6.3%** y latencias $p95 > 1900\text{ ms}$ en `payments` y `checkout`. La detección automática mediante el modelo estacional (`anomaly/detect.py`) alertó en **2 minutos**, el Incident Commander activó el protocolo de contención, revirtió el cambio y ejecutó el procedimiento de recuperación verificada en **24 minutos** (frente al MTTR histórico de **7.17 horas** en Sev1 de la organización).

| Métrica de Respuesta | Valor en el Simulacro | Línea Base Histórica (`org-incidents.csv`) | Mejora Lograda |
| :--- | :---: | :---: | :---: |
| **Tiempo hasta Detectar (MTTD)** | **2.0 min** | ~45 min (alertas manuales) | **$-95.6\%$** |
| **Tiempo hasta Mitigar / Recuperar (MTTR)** | **24.0 min (0.40 h)** | **7.17 horas** (media Sev1) | **$-94.4\%$** |
| **Transacciones Afectadas** | 1.8% durante 14 min (reintentadas vía cola) | Caída total de 2.9 h a 13.0 h | Cumple RTO $< 4\text{ h}$ |

---

## 2. Línea de Tiempo Detallada (UTC)

- **`18:00:00Z` (Inyección / Inicio del fallo):** Se aplica un cambio de configuración en `ledger` que incrementa el paralelismo de consultas sin pooler (`PgBouncer`), saturando `max_connections` en PostgreSQL.
- **`18:02:00Z` (Detección — MTTD = 2 min):** La alerta `HighErrorRateSLOBurn` de Prometheus y el detector `anomaly/detect.py` identifican una desviación de $+48\sigma$ en `error_rate` y $+32\sigma$ en `latency_p95_ms`.
- **`18:04:00Z` (Declaración de Sev1 e IC):** El guardia SRE asume el rol de *Incident Commander*, abre el canal de incidente `#inc-sev1-ledger`, asigna *Scribe* y congela despliegues en todos los squads (`freeze` en GitHub Actions).
- **`18:07:00Z` (Contención del Radio de Explosión):** El IC confirma que el Circuit Breaker de `checkout` ([`chaos/exp2-dependency-timeout.sh`](../chaos/exp2-dependency-timeout.sh)) abrió correctamente, aislando el catálogo y la navegación de la caída de `ledger`.
- **`18:11:00Z` (Mitigación — Rollback Inmutable):** En lugar de depurar en caliente sobre producción, el IC ordena promover el digest SHA-256 inmediatamente anterior desde Artifactory y reciclar las conexiones colgadas.
- **`18:16:00Z` (Recuperación de Base de Datos):** El pool de conexiones se estabiliza; `pg_isready` y `/ready` reportan 100% de réplicas saludables (`3/3`).
- **`18:24:00Z` (Verificación y Cierre):** El IC verifica durante 8 minutos consecutivos que `error_rate < 0.40%` y `latency_p95_ms < 125 ms`, y levanta el estado de emergencia.

---

## 3. Análisis de Causa Raíz (5 Porqués — Enfoque Sistémico, Sin Culpa Individual)

1. **¿Por qué cayeron las transacciones de `payments`?** Porque las llamadas síncronas hacia `ledger` excedieron el timeout al saturarse las conexiones de PostgreSQL.
2. **¿Por qué se saturó PostgreSQL?** Porque el despliegue de `ledger` introdujo consultas sin índice y sin límite de pool de conexiones.
3. **¿Por qué llegó ese cambio a producción sin detectarse?** Porque el pipeline de `ledger` (`ejercicios/master/org-workflows/ledger.yml`) ejecutaba `kubectl apply -f k8s/` directamente sin etapa de pruebas (`mvn verify`), sin gate de rendimiento (`loadrunner-mock`) y sin `environment: production`.
4. **¿Por qué se permitía un workflow sin gates en un servicio Tier 0?** Porque no existía validación automática de políticas como código (`supply-chain/policy-check.py`) como *Required Check* organizacional.
5. **¿Por qué tardaban 7.17 h históricamente estos incidentes?** Por cambios manuales no trazados y ausencia de runbooks probados mediante *Game Days*.

---

## 4. Qué Funcionó Bien vs Qué Falló

- **Qué funcionó bien:**
  - La detección por presupuesto de error (SLO Burn Rate) y `anomaly/detect.py` alertó en 2 minutos sin ruido.
  - La separación de roles ICS (IC, Scribe, Operador) evitó que múltiples ingenieros ejecutaran comandos contradictorios en producción.
  - La promoción por digest inmutable permitió revertir en $< 5\text{ minutos}$.
- **Qué falló / Dónde tuvimos suerte:**
  - El workflow original de `ledger` carecía de gates preventivos.
  - La reconciliación de asientos en vuelo requirió una consulta SQL manual de verificación.

---

## 5. Plan de Acción Preventivo (Action Items con Dueño y Fecha Límite)

| Ticket Jira | Acción Correctiva / Preventiva | Tipo | Responsable | Fecha Límite |
| :---: | :--- | :---: | :--- | :---: |
| **`DEVOPS-101`** | Reemplazar `ledger.yml` por el workflow reutilizable `.github/workflows/ci-cd.yml` validado por `supply-chain/policy-check.py` (bloqueando despliegues sin tests ni aprobación). | Preventivo | Tech Lead `ledger` + Plataforma | +5 días |
| **`DEVOPS-102`** | Incorporar `PgBouncer` y límites de conexión por pod en el clúster CloudNativePG según [`ADR-002`](./adr/ADR-002-estrategia-datos-backups.md). | Mitigación | SRE / Data Platform | +10 días |
| **`DEVOPS-103`** | Automatizar el script de reconciliación post-failover dentro de `dr/failover.sh` y probarlo en el próximo *Game Day*. | Detección / Respuesta | Equipo SRE | +14 días |
