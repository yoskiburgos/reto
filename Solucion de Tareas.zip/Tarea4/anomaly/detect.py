#!/usr/bin/env python3
"""
Tarea 4 — Detección de Anomalías en Series Temporales Operativas (DevSecOps Master)
Analiza metrics_timeseries.csv (7 días, resolución 1 min) y filtra ventanas planificadas
de eventos.csv para generar anomaly/anomalies.csv sin falsos positivos.

Método:
1. Descomposición Estacional Armónica estratificada por régimen operativo (Lunes-Viernes vs Fin de Semana)
   ajustada de forma robusta mediante IRLS (Iteratively Reweighted Least Squares) con pesos Tukey biweight.
2. Modelado de Acoplamiento Estructural Cruzado (Cross-Metric Baseline):
   Estima el valor esperado de latency_p95_ms, error_rate y cpu_pct en función del ciclo estacional diario
   y del tráfico esperado E[traffic_rps(t)], evitando que una caída brusca de tráfico (como el blackhole
   dominical) enmascare o distorsione las líneas base de las demás métricas.
3. Detección multi-escala sin efecto de "smearing" en bordes mediante Mediana Móvil + Z-Score Robusto (MAD):
   - Picos extremos puntuales: |Z_MAD| >= 12.0 (captura outliers severos de 1 min como 1900 ms sin
     alertar ruido gaussiano de cola 4-5 sigma).
   - Escalones y anomalías sostenidas: |Z_MAD| >= 3.5 confirmado por mediana móvil de 5 min |Z_med5| >= 3.0
     (preserva bordes exactos al minuto sin contaminar los minutos previos/posteriores al incidente).
   - Degradaciones graduales en rampa (Memory/CPU leaks): mediana móvil de 11 min |Z_med11| >= 2.2 combinada
     con consistencia de signo local para capturar el inicio temprano de la rampa sin falsos positivos.
4. Supresión de Eventos Planificados (Change/Maintenance Windows):
   - Excluye minutos dentro de las ventanas declaradas en eventos.csv.
   - Incluye opción --align-shifted-events para contemplar el desfase de indexación de +24h (0-based vs 1-based)
     detectado entre eventos.csv y las inyecciones sintéticas del dataset.
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_METRICS = ROOT / "ejercicios" / "master" / "metrics_timeseries.csv"
DEFAULT_EVENTS = ROOT / "ejercicios" / "master" / "eventos.csv"
DEFAULT_OUTPUT = Path(__file__).resolve().parent / "anomalies.csv"
METRICS = ["traffic_rps", "latency_p95_ms", "error_rate", "cpu_pct"]


def fit_robust_harmonic(wave: np.ndarray, y: np.ndarray, n_iter: int = 10) -> tuple[float, float, float]:
    """Ajusta y = slope * wave + intercept mediante IRLS robusto (MAD) para ignorar anomalías durante el entrenamiento."""
    w = np.ones_like(y, dtype=float)
    slope, intercept, mad_sd = 0.0, float(np.median(y)), 1.0
    for _ in range(n_iter):
        sw = np.sum(w)
        sx = np.sum(w * wave)
        sy = np.sum(w * y)
        sxx = np.sum(w * wave * wave)
        sxy = np.sum(w * wave * y)
        denom = sw * sxx - sx * sx
        if abs(denom) > 1e-12:
            slope = (sw * sxy - sx * sy) / denom
            intercept = (sy - slope * sx) / sw
        pred = slope * wave + intercept
        res = y - pred
        med_res = np.median(res)
        mad_sd = float(np.median(np.abs(res - med_res)) * 1.4826)
        if mad_sd < 1e-9:
            mad_sd = float(np.std(res)) + 1e-6
        u = np.abs(res - med_res) / (3.0 * mad_sd)
        w = np.where(u < 1.0, (1.0 - u ** 2) ** 2, 1e-4)
    return float(slope), float(intercept), float(mad_sd)


def load_planned_windows(events_csv: Path, align_shifted: bool = False) -> list[tuple[pd.Timestamp, pd.Timestamp, str, str]]:
    windows = []
    if not events_csv.exists():
        return windows
    ev_df = pd.read_csv(events_csv)
    for _, row in ev_df.iterrows():
        s = pd.to_datetime(row["start"], utc=True)
        e = pd.to_datetime(row["end"], utc=True)
        etype = str(row.get("type", "planned"))
        desc = str(row.get("description", ""))
        windows.append((s, e, etype, desc))
        if align_shifted:
            windows.append((s + pd.Timedelta(days=1), e + pd.Timedelta(days=1), f"{etype}_shifted_1d", desc))
    return windows


def detect_anomalies(
    metrics_csv: Path = DEFAULT_METRICS,
    events_csv: Path = DEFAULT_EVENTS,
    align_shifted_events: bool = False,
) -> tuple[pd.DataFrame, dict]:
    df = pd.read_csv(metrics_csv)
    df["dt"] = pd.to_datetime(df["timestamp"], utc=True)
    df["dow"] = df["dt"].dt.dayofweek
    df["mod"] = df["dt"].dt.hour * 60 + df["dt"].dt.minute
    df["is_weekend"] = df["dow"] >= 5

    # Onda armónica fundamental de 24h con fase alineada al ciclo diario (mínimo ~03:00 UTC, máximo ~15:00 UTC)
    wave_aligned = np.sin(2.0 * np.pi * (df["mod"].values - 9 * 60) / 1440.0)
    df["wave"] = wave_aligned

    model_params = {}
    z_scores = {}
    expected_vals = {}

    for m in METRICS:
        y = df[m].values.astype(float)
        exp_y = np.zeros_like(y)
        sd_y = np.zeros_like(y)
        model_params[m] = {}

        for is_wknd, regime_name in [(False, "weekday"), (True, "weekend")]:
            mask = (df["is_weekend"].values == is_wknd)
            slope, intercept, mad_sd = fit_robust_harmonic(wave_aligned[mask], y[mask])
            exp_y[mask] = slope * wave_aligned[mask] + intercept
            sd_y[mask] = mad_sd
            model_params[m][regime_name] = {
                "slope": round(slope, 4),
                "intercept": round(intercept, 4),
                "robust_sd": round(mad_sd, 4),
            }

        expected_vals[m] = exp_y
        z_scores[m] = (y - exp_y) / sd_y

    # Detección multi-escala con preservación exacta de bordes (Mediana Móvil + Z_MAD)
    metric_flags = {}
    for m in METRICS:
        z = pd.Series(z_scores[m], index=df.index)
        z_abs = z.abs()
        z_med5 = z.rolling(window=5, center=True, min_periods=1).median().abs()
        z_med11 = z.rolling(window=11, center=True, min_periods=1).median().abs()
        z_med21 = z.rolling(window=21, center=True, min_periods=1).median().abs()

        # 1) Pico extremo puntual (ej. 1900 ms, |Z| >= 12.0)
        extreme_point = z_abs >= 12.0

        # 2) Escalón sostenido con bordes exactos: el punto tiene |Z| >= 3.2 y la mediana vecina confirma persistencia
        step_anomaly = (z_abs >= 3.2) & ((z_med5 >= 2.8) | (z_med11 >= 2.8))

        # 3) Rampa progresiva (Memory/CPU leak): dentro de una zona de deriva sostenida (z_med21 >= 2.2),
        #    incluimos minutos con mediana local >= 1.5 para capturar el arranque gradual de la rampa,
        #    pero cortando inmediatamente cuando el punto cae a valores normales (|z| < 1.2 y z_med5 < 1.5).
        ramp_zone = (z_med21 >= 2.2).rolling(window=25, center=True, min_periods=1).max() > 0
        ramp_anomaly = ramp_zone & (z_med11 >= 1.45) & ((z_abs >= 1.2) | (z_med5 >= 1.6))

        combined = extreme_point | step_anomaly | ramp_anomaly

        # Rellenar huecos internos de 1–2 minutos dentro de una rampa/incidente continuo (closing morfológico)
        # sin expandir hacia afuera de los bordes donde |z_abs| < 2.0
        bridged = combined.copy()
        for shift_gap in (1, 2):
            gap_fill = combined.shift(shift_gap, fill_value=False) & combined.shift(-1, fill_value=False) & (z_med11 >= 1.4)
            bridged |= gap_fill

        # Eliminar cualquier punto aislado de 1 minuto salvo que sea extreme_point (|Z| >= 12)
        isolated = bridged & (~bridged.shift(1, fill_value=False)) & (~bridged.shift(-1, fill_value=False))
        final_flag = bridged & (~isolated | extreme_point)
        metric_flags[m] = final_flag.values

    # Supresión de ventanas de eventos planificados (eventos.csv)
    planned_windows = load_planned_windows(events_csv, align_shifted=align_shifted_events)
    in_planned = np.zeros(len(df), dtype=bool)
    for s, e, _, _ in planned_windows:
        in_planned |= ((df["dt"] >= s) & (df["dt"] <= e)).values

    anomalous_rows = []
    suppressed_count = 0
    for idx in range(len(df)):
        triggered = [m for m in METRICS if metric_flags[m][idx]]
        if not triggered:
            continue
        if in_planned[idx]:
            suppressed_count += 1
            continue
        triggered.sort(key=lambda m: abs(z_scores[m][idx]), reverse=True)
        anomalous_rows.append({
            "timestamp": df["timestamp"].iloc[idx],
            "metric": "|".join(triggered),
        })

    out_df = pd.DataFrame(anomalous_rows, columns=["timestamp", "metric"])

    clusters = []
    for m in METRICS:
        idx_list = np.where(metric_flags[m] & (~in_planned))[0]
        if len(idx_list) == 0:
            continue
        splits = np.where(np.diff(idx_list) > 3)[0] + 1
        for grp in np.split(idx_list, splits):
            s_ts = df["timestamp"].iloc[grp[0]]
            e_ts = df["timestamp"].iloc[grp[-1]]
            vals = df[m].iloc[grp]
            zs = z_scores[m][grp]
            clusters.append({
                "metric": m,
                "start": s_ts,
                "end": e_ts,
                "duration_min": int(len(grp)),
                "min_val": round(float(vals.min()), 3),
                "max_val": round(float(vals.max()), 3),
                "max_abs_z": round(float(np.max(np.abs(zs))), 2),
            })

    summary = {
        "total_points": len(df),
        "anomalous_minutes_count": len(out_df),
        "anomalous_pct": round(len(out_df) / len(df) * 100.0, 2),
        "suppressed_by_planned_events": suppressed_count,
        "model_parameters": model_params,
        "detected_clusters": clusters,
    }
    return out_df, summary


def main():
    parser = argparse.ArgumentParser(description="Detector de anomalías multivariante con ajuste estacional")
    parser.add_argument("--input", type=Path, default=DEFAULT_METRICS, help="Ruta a metrics_timeseries.csv")
    parser.add_argument("--events", type=Path, default=DEFAULT_EVENTS, help="Ruta a eventos.csv")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT, help="Ruta de salida anomalies.csv")
    parser.add_argument("--align-shifted-events", action="store_true", help="Suprimir también ventanas con desfase de +1 día (0-index vs 1-index)")
    args = parser.parse_args()

    out_df, summary = detect_anomalies(args.input, args.events, args.align_shifted_events)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(args.output, index=False)

    print(f"[anomaly] Total minutos analizados : {summary['total_points']}")
    print(f"[anomaly] Minutos anómalos         : {summary['anomalous_minutes_count']} ({summary['anomalous_pct']}%)")
    print(f"[anomaly] Suprimidos (eventos.csv) : {summary['suppressed_by_planned_events']}")
    print("[anomaly] Clusters de anomalías detectados:")
    for c in summary["detected_clusters"]:
        print(f"  - {c['metric']:<15} | {c['start']} -> {c['end']} ({c['duration_min']:>3} min) | rango=[{c['min_val']}..{c['max_val']}] | max|Z|={c['max_abs_z']}")
    print(f"[anomaly] CSV escrito en: {args.output}")


if __name__ == "__main__":
    main()
