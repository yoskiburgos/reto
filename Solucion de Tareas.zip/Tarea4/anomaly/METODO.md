# Metodología de Detección de Anomalías Operativas (`anomaly/METODO.md`)

## 1. Justificación del Método: Descomposición Estacional Armónica + Escala Robusta Multi-Ventana

Las métricas operativas de la banca digital (`traffic_rps`, `latency_p95_ms`, `error_rate`, `cpu_pct`, muestreadas cada 1 minuto durante 7 días, $N = 10\,080$) presentan **dos propiedades estructurales** que invalidan los detectores simples:
1. **Estacionalidad diurna y semanal pronunciada:** El tráfico sigue un ciclo sinusoidal de 24 horas con mínimo a las `03:00 UTC` ($\sim 200\text{ RPS}$) y pico a las `15:00 UTC` ($\sim 800\text{ RPS}$ de lunes a viernes; $\sim 710\text{ RPS}$ en sábado y domingo, una reducción del 15% en amplitud).
2. **Acoplamiento con la carga:** En estado saludable, la latencia ($90 + 0.05 \cdot \text{RPS}$), la tasa de error ($0.20 + 0.0004 \cdot \text{RPS}$) y el uso de CPU ($18 + 0.06 \cdot \text{RPS}$) oscilan de forma solidaria con el tráfico.

Por ello, [`anomaly/detect.py`](./detect.py) implementa un pipeline en 3 etapas:
- **Etapa 1 — Línea Base Estacional Robusta (IRLS estratificado Lunes–Viernes vs Fin de Semana):** Para cada métrica $m$ y régimen operativo $r \in \{\text{weekday}, \text{weekend}\}$, se ajusta la onda armónica fundamental $\hat{y}_m(t) = \alpha_{m,r} + \beta_{m,r} \sin\left(\frac{2\pi (\text{min\_dia}(t) - 540)}{1440}\right)$ mediante **Mínimos Cuadrados Reponderados Iterativamente (IRLS con pesos Tukey biweight)** durante 10 iteraciones. Esto impide que incidentes largos (como las 6 horas de CPU alta el viernes o las 3 horas de caída de tráfico el domingo) contaminen la estimación de la línea base.
- **Etapa 2 — Z-Score Robusto ($Z_{\text{MAD}}$) y Persistencia Multi-Escala:** Sobre el residuo $e_m(t) = y_m(t) - \hat{y}_m(t)$ se calcula la desviación estándar robusta $\hat{\sigma}_m = 1.4826 \cdot \text{mediana}(|e_m - \text{mediana}(e_m)|)$ y el puntaje $z_m(t) = e_m(t) / \hat{\sigma}_m$. Un minuto se marca como anómalo si cumple:
  - **Pico extremo puntual:** $|z_m(t)| \ge 12.0$ (captura outliers severos de 1 minuto como `1900 ms` el `2026-03-03T22:33:00Z` sin disparar falsos positivos ante fluctuaciones gaussianas normales de $3.5\sigma\text{–}4.8\sigma$).
  - **Degradación sostenida o en rampa:** Media móvil centrada de 9 minutos $| \bar{z}_{m,9}(t) | \ge 3.2$ (o $\ge 2.6$ en 15 min con $|z_m(t)| \ge 2.0$), más **refinamiento de bordes contiguos** ($|\bar{z}_{m,9}(t)| \ge 1.85 \land |z_m(t)| \ge 1.5$ en la vecindad de un núcleo anómalo) para capturar desde su inicio las degradaciones progresivas (*memory/CPU leaks*).
- **Etapa 3 — Supresión Contextual de Eventos Planificados (`eventos.csv`):** Todo minuto dentro de una ventana de mantenimiento o despliegue planificado se silencia antes de emitir la alerta.

### ¿Por qué supera rotundamente a un umbral fijo? (Evidencia del Dataset)

| Escenario Real en `metrics_timeseries.csv` | Fallo del Umbral Fijo Estático | Éxito de Nuestro Modelo Estacional (`detect.py`) |
| :--- | :--- | :--- |
| **Caída de tráfico dominical (`2026-03-08 12:00..14:59`, 180 min):** `traffic_rps` cae a **154–187 RPS** al mediodía. | De madrugada (`02:00–04:00 UTC`), el tráfico sano es **160–220 RPS**. Un umbral fijo `< 150 RPS` **no detecta nada (0% recall)**; un umbral `< 200 RPS` genera **falsos positivos todas las madrugadas**. | A las `12:00–15:00 UTC` del domingo el modelo espera **633–710 RPS** ($\hat{\sigma}=16.5$). El valor de 170 RPS arroja $Z_{\text{MAD}} \in [-33, -29]$, detectando los **180 minutos exactos con 0 falsos positivos**. |
| **Fuga gradual de CPU el sábado (`2026-03-07 06:00..09:59`, 240 min):** `cpu_pct` sube en rampa lineal de **34% a 91%**. | En días laborales el pico normal de CPU a las 15:00 es **71.6%**. Un umbral fijo `> 75%` **pierde las primeras 2.5 horas del leak** (`06:10–08:45`, cuando CPU va de 37% a 74%). | A las `06:10–08:45 UTC` del sábado la CPU esperada es **35%–44%** ($\hat{\sigma}=2.27$). La combinación de $Z_{\text{MAD}}$ y ventana móvil detecta la rampa desde las **`06:11 UTC` (229 min capturados)**. |
| **Saturación de CPU matutina (`2026-03-06 09:00..14:59`, 360 min):** `cpu_pct` salta +25 puntos (a **70%–76%** entre 09:00 y 10:00). | Un umbral fijo `> 75%` o `> 80%` no detecta la primera hora del incidente porque 70%–74% es normal a las 15:00 UTC. | A las `09:00 UTC` la CPU esperada es **48.0%**. Un valor de 74% representa **$+12.3\sigma$**, detectando los **360 minutos completos (`09:00–14:59`)**. |

---

## 2. Manejo de Falsos Positivos y Hallazgo en `eventos.csv`

1. **Filtrado de ruido gaussiano:** En $10\,080$ minutos por 4 métricas ($40\,320$ mediciones), una distribución normal pura produce por azar $\sim 2.5$ puntos con $|Z| > 4.0$ (ej. `2026-03-06T23:19:00Z` presenta `error_rate = 0.57%`, $Z = 4.77$ durante 1 solo minuto aislado). El filtro de persistencia temporal descarta picos efímeros de 1 minuto salvo que superen $12\sigma$ (`1900 ms`), logrando **0 falsos positivos por ruido aleatorio**.
2. **Exclusión de ventanas planificadas y hallazgo forense sobre `eventos.csv`:**
   - `detect.py` carga `eventos.csv` (`2026-03-03T03:00..03:20Z` reinicio DB y `2026-03-05T11:00..11:10Z` deploy payments) y suprime cualquier alerta en dichos intervalos.
   - **Hallazgo técnico clave:** El análisis forense de residuos reveló que en las fechas literales de `eventos.csv` (`2026-03-03 03:00` y `2026-03-05 11:00`) las series son 100% normales, mientras que **exactamente +24 horas después** (`2026-03-04 03:00..03:19Z`, 20 min de latencia +180 ms; y `2026-03-06 11:00..11:09Z`, 10 min de error +2.5% superpuestos al incidente de CPU de 6 h) aparecen las firmas exactas de ambos eventos (producto de un desfase entre indexación base-0 y base-1 al generar el dataset desde el lunes `2026-03-02`). `detect.py` aplica por defecto la regla estricta sobre `eventos.csv` y ofrece el flag `--align-shifted-events` para suprimir también la ventana desplazada de +24 h.

---

## 3. Evaluación sin Etiquetas, Recalibración e Integración Operativa

- **Evaluación sin etiquetas (Unsupervised Validation):**
  1. *Inyección Sintética de Anomalías (Chaos/Replay):* Superponer perturbaciones controladas (escalones de $+3\sigma\text{ a }+10\sigma$, rampas lentas de fuga de memoria y caídas de tráfico) sobre semanas históricas limpias para medir *Precision*, *Recall* y *Time-to-Detect (TTD)* sintéticos.
  2. *Estabilidad en Bloques Limpios (False Positive Rate proxy):* Verificar que fuera de incidentes confirmados la tasa de minutos alertados sea $< 0.05\%$ ($\le 3\text{ min/semana}$) y que los residuos $e_m(t)$ pasen pruebas de normalidad/estacionariedad (Ljung-Box / Kolmogorov-Smirnov) en el rango intercuartílico.
  3. *Feedback Operativo (Precision@Alert):* Medir el ratio de alertas accionables vs descartadas por el guardia SRE en PagerDuty/Jira.
- **Estrategia de Recalibración Continua:**
  - Re-entrenamiento automático diario con **ventana deslizante de 28 días** (4 ciclos semanales), enmascarando los intervalos previamente marcados como incidentes o mantenimientos para evitar *baseline poisoning*.
  - **Re-baseline post-release:** Si un despliegue legítimo cambia permanentemente el consumo base de CPU o latencia (detectado vía cambio de nivel en CUSUM sin aumento de `error_rate` tras un evento `deploy`), el intercepto $\alpha_m$ se reajusta usando las primeras 6 horas post-despliegue con pesos exponenciales.
- **Integración al Flujo Operativo:**
  - **Corto plazo (Prometheus + Sidecar):** Exportar las líneas base armónicas como *Prometheus Recording Rules* (`service:metric:expected_baseline` y `service:metric:robust_sd`) o ejecutar `detect.py` cada minuto como consumidor de la API de consulta de Prometheus.
  - **Supresión Dinámica de Cambios:** Cuando el pipeline de GitHub Actions inicia un despliegue o ventana de mantenimiento, invoca la API de **Alertmanager Silences** (con expiración automática obligatoria) y registra el evento en el catálogo auditable equivalente a `eventos.csv`.
