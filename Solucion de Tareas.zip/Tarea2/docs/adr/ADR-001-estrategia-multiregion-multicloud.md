# ADR-001: Estrategia de Resiliencia Multi-Región vs Multi-Cloud

- **Estado:** Aceptado
- **Fecha:** 2026-10-16
- **Decisores:** Referente Técnico DevSecOps Master, CIO, Arquitectura Empresarial
- **Contexto Organizacional:** Banca digital regulada (12 squads, ~85 ingenieros, equipo de plataforma de **6 FTE**). Actualmente opera sobre un único clúster AKS en una sola región de Azure sin DR probado, con un objetivo declarado de **RTO = 4 h** y **RPO = 15 min**, y un MTTR real en incidentes Sev1 de **7.17 horas**.

---

## 1. Contexto y Problema

El banco enfrenta dos exigencias simultáneas:
1. **Regulatoria y de Continuidad de Negocio:** Garantizar la recuperación ante la caída completa de la región primaria de nube dentro de los umbrales comprometidos con el regulador financiero, con evidencia auditable cada trimestre.
2. **Restricción severa de capacidad operativa (6 FTE):** Cualquier arquitectura cuya operación diaria consuma más de 1.5–2 FTE en mantenimiento de infraestructura dejará sin soporte la migración de Jenkins, el gobierno de pipelines y la reducción del Change Failure Rate en los 12 squads.

---

## 2. Decisión

Adoptar una arquitectura **Multi-Región Activo-Pasivo Tibio (*Warm Standby*) dentro del mismo proveedor Cloud (Azure AKS Región Primaria + Región Secundaria Apareada)** gobernada declarativamente por **GitOps (ArgoCD)**, combinada con **copia inmutable de respaldos (WORM) hacia un segundo proveedor de almacenamiento (Cross-Cloud Storage Bunker en AWS S3 Object Lock)** para protección ante riesgos catastróficos de cuenta/proveedor.

### Arquitectura Seleccionada
- **Cómputo (AKS):**
  - *Región Primaria (Activa):* Clúster AKS desplegado en 3 Zonas de Disponibilidad (Multi-AZ) para absorber fallos de datacenter local con **RTO = 0 y RPO = 0**.
  - *Región Secundaria DR (Warm Standby):* Clúster AKS con plano de control activo, nodos de sistema y servicios **Tier 0 (`checkout`, `payments`, `ledger`, `fraud`)** pre-desplegados a capacidad mínima (2 réplicas) con *Cluster Autoscaler / Karpenter* listo para escalar en $< 90\text{ segundos}$ al recibir tráfico. Los servicios Tier 1 y Tier 2 se sincronizan vía ArgoCD y escalan bajo demanda durante el failover.
- **Enrutamiento y Tráfico:** Azure Front Door / Traffic Manager con *health probes* cada 10 s hacia `/ready` y `/health`, permitiendo conmutación controlada por DNS/Anycast en $< 60\text{ s}$.
- **Búnker de Respaldo Cross-Cloud (Regla de Salida Regulatoria):** Aunque el cómputo de DR es mono-nube (Azure), los snapshots físicos y archivos WAL cifrados con claves gestionadas por el banco (BYOK) se replican asíncronamente a un bucket inmutable en AWS S3 (`Object Lock` en modo *Compliance*), mitigando el riesgo de secuestro de cuenta o bloqueo administrativo del proveedor primario sin pagar el costo operativo de correr Kubernetes en dos nubes.

---

## 3. Alternativas Consideradas y Descartadas

### Alternativa A (Descartada): Multi-Cloud Activo-Activo (AKS en Azure + EKS en AWS simultáneos)
- **Descripción:** Distribuir tráfico productivo en tiempo real 50/50 entre Azure AKS y AWS EKS con bases de datos distribuidas multi-región/multi-nube.
- **Motivos de descarte:**
  1. **Inviable con 6 FTE (Complejidad Cognitiva y Operativa):** Obliga a mantener por duplicado IAM/OIDC, CNI, políticas de red, controladores de Ingress, módulos de Terraform y observabilidad en dos nubes distintas. Solo operar esa capa absorbería 4 de los 6 FTE.
  2. **Latencia y Consistencia Transaccional (`ledger`, `payments`):** La replicación síncrona cross-cloud introduce latencias de red de $15\text{–}60\text{ ms}$ por *commit* y riesgo de *Split-Brain* contable; la replicación asíncrona activo-activo genera conflictos de escritura en saldos bancarios.
  3. **Brecha de Habilidades:** El diagnóstico de `org-teams.csv` muestra que 4 squads críticos tienen $\le 2$ certificaciones Cloud; exigirles operar cargas multi-nube aumentaría los incidentes por `config drift` (hoy 10% de los incidentes) y `cambio manual en prod`.

### Alternativa B (Descartada): DR Cold Standby (Crear el clúster DR desde cero vía Terraform al ocurrir el desastre)
- **Descripción:** No mantener clúster secundario; ejecutar `terraform apply` + restauración de backups solo cuando cae la región primaria.
- **Motivos de descarte:**
  1. **Riesgo de incumplir RTO en caídas masivas de región:** Durante una caída regional real de un proveedor cloud, el plano de control de creación de recursos (ARM/EC2 API) y la capacidad de instancias en la región vecina sufren congestión severa (*thundering herd*). Levantar un clúster AKS desde cero, descargar imágenes y restaurar bases de datos bajo presión supera fácilmente las 4 h (nuestro MTTR actual en Sev1 ya es de **7.17 h**).
  2. **Deriva silenciosa:** Un entorno que no existe continuamente no puede validarse de forma continua con sintéticos ni *Game Days* ligeros.

### Alternativa C (Descartada): Mantener un Único Clúster Mono-Región Solo con Multi-AZ
- **Descripción:** Confiar exclusivamente en 3 Zonas de Disponibilidad dentro de una sola región.
- **Motivos de descarte:**
  1. No protege contra fallos de servicios regionales compartidos (plano de control regional, actualizaciones defectuosas de red regional o desastres geográficos) ni satisface el requerimiento de auditoría bancaria de recuperación ante desastres regional.

---

## 4. Consecuencias y Trade-offs

- **Positivas:**
  - Reduce el **RTO efectivo a $< 15\text{ minutos}$** para Tier 0 (muy por debajo de las 4 h declaradas) con un sobrecosto de infraestructura inferior al 25% respecto a producción (nodos DR dimensionados al mínimo en reposo).
  - Homogeneidad total de herramientas (un solo stack AKS + OIDC + ArgoCD), permitiendo que los 6 FTE dediquen el 80% de su tiempo a automatizar los 12 squads.
- **Negativas / Riesgos Mitigados:**
  - Requiere disciplina estricta de GitOps: ningún cambio puede aplicarse manualmente en `primary` (`kubectl apply` humano prohibido), pues de lo contrario el clúster `dr` tendría deriva de configuración al momento del failover. Esto se controla mediante ArgoCD `selfHeal: true` y la política `CD-001` en `supply-chain/policy-check.py`.
