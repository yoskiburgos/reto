# ADR-002: Estrategia de Datos, Replicación y Backups para Cumplimiento de RPO/RTO

- **Estado:** Aceptado
- **Fecha:** 2026-10-16
- **Decisores:** Referente Técnico DevSecOps Master, Arquitectura de Datos, SRE, Seguridad/Auditoría
- **Contexto Técnico:** El drill ejecutado en la Tarea 2 ([`dr/drill-report.md`](../../dr/drill-report.md)) demostró empíricamente que el esquema actual basado en un `StatefulSet` simple (`k8s-base/postgres-dr.yaml`) y volcados lógicos periódicos (`pg_dump`) **pierde todas las transacciones confirmadas entre snapshots** (200 transacciones / `$660,300 USD` perdidas en una ventana de 8 min 12 s) y escala linealmente en tiempo de restauración con el volumen de datos.

---

## 1. Contexto y Problema

En una banca digital, los datos tienen perfiles de criticidad asimétricos:
- **Tier 0 (`ledger`, `payments`, `checkout`):** Asientos contables y pagos donde perder transacciones ya confirmadas al usuario (RPO $> 0$) genera descuadre financiero, riesgo legal y pérdida directa de dinero.
- **Tier 1 / Tier 2 (`catalog`, `identity`, `reporting`, `notifications`, `data-platform`):** Soportan un RPO de 5 a 15 minutos siempre que exista recuperación a un punto exacto en el tiempo (*Point-in-Time Recovery*, PITR) ante borrados accidentales o despliegues defectuosos.

El mecanismo tradicional de `CronJob` con `pg_dump` cada 15 minutos presenta **tres fallos estructurales**:
1. **Brecha de RPO:** Un fallo en el minuto 14:59 (o el fallo de una ejecución de `CronJob`) produce pérdidas de 15 a 30 minutos de transacciones.
2. **Penalización de rendimiento e I/O:** Ejecutar `pg_dump` completo cada 15 minutos sobre tablas de decenas de GB satura el I/O de disco y retiene *locks* compartidos que bloquean migraciones DDL.
3. **Lentitud de restauración (RTO):** Reconstruir índices B-Tree desde un archivo `.sql` texto en frío tarda horas en bases medianas/grandes.

---

## 2. Decisión

Adoptar una arquitectura de persistencia gestionada por el operador **CloudNativePG (CNPG)** (o servicio administrado equivalente con réplica cross-región) basada en **Backups Físicos Incrementales + Archivado Continuo de WAL (Write-Ahead Log) a Object Storage Inmutable + Réplica de Streaming en el Clúster DR**:

1. **Alta Disponibilidad Local (In-Region HA — RPO = 0, RTO < 10 s):**
   - Clúster PostgreSQL de 3 instancias (1 Primary + 2 Standby en distintas Zonas de Disponibilidad) con replicación por *quorum* síncrono (`synchronous_commit = on` para `ledger` y `payments`). Si cae un nodo o una AZ, el operador promueve la réplica síncrona automáticamente en $< 10\text{ segundos}$ con **0 transacciones perdidas**.
2. **Recuperación ante Desastres Regional (Cross-Region DR — RPO < 5 s, RTO < 2 min):**
   - Un *Replica Cluster* en la región `dr` conectado por **Streaming Replication asíncrono continuo** + consumo de WAL desde Object Storage. Al estar los archivos de datos físicos ya hidratados en disco, el failover (`dr/failover.sh`) solo ejecuta la promoción del clúster secundario sin reconstruir tablas ni índices desde un `.sql`.
3. **Point-in-Time Recovery (PITR) y Backups Inmutables Anti-Ransomware:**
   - **Backup físico base diario** (vía Barman Cloud / `pgBackRest`) + **envío continuo de segmentos WAL** (`archive_timeout = 60s` para forzar rotación incluso en bajo tráfico) hacia almacenamiento de objetos con **WORM / Object Lock** (retención de 90 días para auditoría trimestral).
   - Permite restaurar la base de datos al segundo exacto previo a un error humano o `deploy sin pruebas` (que hoy representa el 23.3% de los incidentes de la organización).
4. **Verificación Automatizada de Restauración (Backup Testing Pipeline):**
   - Un workflow programado diario levanta una instancia efímera a partir del último backup físico + WAL, ejecuta consultas de integridad contable (`SUM(debits) == SUM(credits)`) y publica el reporte en `docs/evidencias/` para la auditoría trimestral.

---

## 3. Alternativas Consideradas y Descartadas

### Alternativa A (Descartada): Mantener `CronJob` con `pg_dump` reduciendo el intervalo a cada 1 o 5 minutos
- **Motivos de descarte:**
  1. Invocar `pg_dump` completo cada 1–5 minutos es inviable en cuanto la base supera unos pocos GB: el tiempo de volcado supera al intervalo del cron, provocando solapamiento de procesos, degradación de latencia $p95$ en producción y desgaste de IOPS.
  2. No ofrece PITR al segundo intermedio entre dos volcados ni resuelve el lento tiempo de reconstrucción de índices durante el `psql` de restauración.

### Alternativa B (Descartada): Snapshots exclusivos de Volumen de Bloque (CSI / Azure Managed Disk Snapshots) sin integración con PostgreSQL
- **Motivos de descarte:**
  1. Un snapshot de disco tomado en caliente sin coordinar `pg_backup_start()` / `pg_backup_stop()` ni archivar los segmentos WAL equivale a un *crash recovery* sucio y sigue teniendo la granularidad del intervalo del snapshot (15–60 min), sin permitir PITR fino ni garantizar consistencia entre múltiples volúmenes (`PGDATA` vs `PGWAL`).

### Alternativa C (Descartada): Migrar todas las bases de datos a un motor NewSQL Distribuido (CockroachDB / Spanner)
- **Motivos de descarte:**
  1. Exigiría reescribir esquemas, consultas, manejo de reintentos de serialización y drivers en los microservicios de los squads, distrayendo de las prioridades críticas del año 1 (erradicar cambios manuales y cerrar brecha SAST/SCA) y excediendo el presupuesto y capacidad de los 6 FTE.

---

## 4. Consecuencias y Matriz Final de RPO / RTO por Tier

| Tier | Servicios | Mecanismo de Protección | RPO Real Alcanzado | RTO Real Alcanzado |
| :---: | :--- | :--- | :---: | :---: |
| **Tier 0** | `ledger`, `payments`, `checkout`, `fraud` | HA Síncrona Multi-AZ + Streaming Replica en Región DR + Continuo WAL WORM | **0 s (In-Region)**<br>**< 5 s (Cross-Region)** | **< 10 s (In-Region)**<br>**< 2 min (Cross-Region)** |
| **Tier 1** | `catalog`, `search`, `identity`, `mobile-*` | HA Multi-AZ + Backup Físico Diario + Archivado Continuo WAL (PITR) | **< 60 s** (`archive_timeout=60s`) | **< 15 min** |
| **Tier 2** | `reporting`, `notifications`, `data-platform` | Backup Físico/Incremental cada 6 h + Archivado WAL (`archive_timeout=300s`) | **< 5 min** | **< 45 min** |
